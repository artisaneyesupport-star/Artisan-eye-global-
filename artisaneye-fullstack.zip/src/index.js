require('dotenv').config();

// Validate required environment variables before starting anything
const validateEnv = require('./utils/validateEnv');
validateEnv();

const http       = require('http');
const app        = require('./app');
const prisma     = require('./config/prisma');
const initSocket = require('./config/socket');
const initCron   = require('./config/cron');

const PORT = process.env.PORT || 4000;

// Unified CORS options — used by both Express (app.js) and Socket.io
const corsOptions = {
  origin: (origin, callback) => {
    const allowed = [
      process.env.FRONTEND_URL,
      `http://localhost:${PORT}`,
      'http://localhost:3000',
    ].filter(Boolean);
    if (!origin || allowed.includes(origin)) callback(null, true);
    else callback(new Error(`CORS: origin ${origin} not allowed`));
  },
  credentials: true,
};

async function start() {
  try {
    await prisma.$connect();
    console.log('✅  Database connected');

    const httpServer = http.createServer(app);
    const io = initSocket(httpServer, corsOptions);
    app.set('io', io);

    initCron(prisma);

    httpServer.listen(PORT, () => {
      console.log(`🚀  ArtisanEye API  →  http://localhost:${PORT}`);
      console.log(`⚡  Socket.io       →  ws://localhost:${PORT}`);
      console.log(`📋  Environment     →  ${process.env.NODE_ENV || 'development'}`);
      console.log('\n  Auth:        /api/auth/*');
      console.log('  Artisans:    /api/artisans/*  (Cloudinary photos)');
      console.log('  Jobs:        /api/jobs/*');
      console.log('  Messaging:   /api/messages/*');
      console.log('  Payments:    /api/payments/*');
      console.log('  Email:       /api/email/*');
      console.log('  Admin:       /api/admin/*');
      console.log('  Contact:     /api/contact');
      console.log('  Health:      /health\n');
    });
  } catch (err) {
    console.error('❌  Failed to start:', err.message);
    process.exit(1);
  }
}

process.on('SIGINT', async () => {
  await prisma.$disconnect();
  console.log('\n🛑  Shut down gracefully.');
  process.exit(0);
});

start();
