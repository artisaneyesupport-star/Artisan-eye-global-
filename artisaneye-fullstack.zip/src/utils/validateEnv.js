/**
 * validateEnv.js
 * ===============
 * Validates required environment variables at startup.
 * Kills the server with a clear error if anything critical is missing.
 * Called once from src/index.js before anything else.
 */

const REQUIRED = [
  { key: 'DATABASE_URL',       hint: 'PostgreSQL connection string, e.g. postgresql://user:pass@host:5432/artisaneye' },
  { key: 'JWT_ACCESS_SECRET',  hint: 'At least 32 chars. Generate: node -e "console.log(require(\'crypto\').randomBytes(64).toString(\'hex\'))"' },
  { key: 'JWT_REFRESH_SECRET', hint: 'Must be different from JWT_ACCESS_SECRET. Generate the same way.' },
];

const WARNINGS = [
  { key: 'CLOUDINARY_CLOUD_NAME', hint: 'Photo uploads will fail without this.' },
  { key: 'PAYSTACK_SECRET_KEY',   hint: 'Payments will fail without this.' },
  { key: 'SMTP_HOST',             hint: 'Emails will not send without SMTP config (dev uses Ethereal automatically).' },
  { key: 'SUPPORT_EMAIL',         hint: 'Contact form emails have no destination.' },
];

function validateEnv() {
  const missing = REQUIRED.filter(({ key }) => !process.env[key]);

  if (missing.length > 0) {
    console.error('\n❌  Missing required environment variables:\n');
    missing.forEach(({ key, hint }) => {
      console.error(`  ${key}`);
      console.error(`    → ${hint}\n`);
    });
    console.error('  Add these to your .env file and restart.\n');
    process.exit(1);
  }

  // Warn if JWT secrets are too short
  const accessSecret  = process.env.JWT_ACCESS_SECRET  || '';
  const refreshSecret = process.env.JWT_REFRESH_SECRET || '';

  if (accessSecret.length < 32) {
    console.warn('⚠️   JWT_ACCESS_SECRET is too short — use at least 32 characters.');
  }
  if (refreshSecret.length < 32) {
    console.warn('⚠️   JWT_REFRESH_SECRET is too short — use at least 32 characters.');
  }
  if (accessSecret === refreshSecret) {
    console.warn('⚠️   JWT_ACCESS_SECRET and JWT_REFRESH_SECRET are identical — they must be different.');
  }

  // Warn about optional but important vars
  if (process.env.NODE_ENV === 'production') {
    const missingOptional = WARNINGS.filter(({ key }) => !process.env[key]);
    if (missingOptional.length > 0) {
      console.warn('\n⚠️   Optional env vars not set (some features will be disabled):');
      missingOptional.forEach(({ key, hint }) => {
        console.warn(`  ${key}: ${hint}`);
      });
      console.warn('');
    }
  }

  console.log('✅  Environment variables validated');
}

module.exports = validateEnv;
