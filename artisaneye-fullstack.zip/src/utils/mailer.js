/**
 * ArtisanEye — Mailer
 * ===================
 * Nodemailer transport + branded HTML email templates.
 *
 * In development, if SMTP_HOST is "smtp.ethereal.email" or not set,
 * we auto-create an Ethereal test account and log the preview URL
 * to the console so you can inspect emails without a real inbox.
 *
 * In production, set real SMTP credentials in .env.
 */

const nodemailer = require('nodemailer');

// ─── Transport ────────────────────────────────────────────────────────

let _transport = null;

async function getTransport() {
  if (_transport) return _transport;

  const isDev = process.env.NODE_ENV !== 'production';
  const useEthereal =
    isDev && (!process.env.SMTP_HOST || process.env.SMTP_HOST === 'smtp.ethereal.email');

  if (useEthereal) {
    // Auto-create a free Ethereal test account
    const testAccount = await nodemailer.createTestAccount();
    _transport = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: { user: testAccount.user, pass: testAccount.pass },
    });
    console.log('[mailer] Using Ethereal test account:', testAccount.user);
    console.log('[mailer] Preview emails at: https://ethereal.email/messages');
  } else {
    _transport = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }

  return _transport;
}

// ─── Base template ────────────────────────────────────────────────────

const BRAND_BLUE      = '#1B3A5C';
const BRAND_TERRA     = '#E8743B';
const BRAND_CREAM     = '#FAF6EF';
const BRAND_CLAY_LINE = '#D8CFC0';

function baseTemplate(title, contentHtml) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
<style>
  body { margin:0; padding:0; background:${BRAND_CREAM}; font-family: Arial, sans-serif; }
  .wrap { max-width:560px; margin:0 auto; padding:32px 16px; }
  .card { background:#fff; border:1.5px solid #1A1A1A; border-radius:5px; overflow:hidden; }
  .card-head { background:${BRAND_BLUE}; padding:28px 32px; }
  .brand { display:flex; align-items:center; gap:10px; color:#fff; font-size:18px; font-weight:800; text-decoration:none; }
  .brand-mark { width:32px; height:32px; }
  .card-body { padding:32px; }
  h1 { color:${BRAND_BLUE}; font-size:22px; margin:0 0 14px; line-height:1.2; }
  p  { color:#3c3c3c; font-size:15px; line-height:1.65; margin:0 0 16px; }
  .btn {
    display:inline-block; background:${BRAND_TERRA}; color:#fff;
    font-weight:700; font-size:15px; text-decoration:none;
    padding:14px 28px; border-radius:3px; margin:8px 0 20px;
  }
  .btn-ghost {
    display:inline-block; border:2px solid ${BRAND_BLUE}; color:${BRAND_BLUE};
    font-weight:700; font-size:14px; text-decoration:none;
    padding:11px 22px; border-radius:3px; margin:8px 0 20px;
  }
  .divider { border:none; border-top:1px solid ${BRAND_CLAY_LINE}; margin:24px 0; }
  .small { font-size:12px; color:#999; }
  .detail-table { width:100%; border-collapse:collapse; margin:16px 0; }
  .detail-table td { padding:10px 12px; border-bottom:1px solid ${BRAND_CLAY_LINE}; font-size:14px; }
  .detail-table td:first-child { color:#888; width:40%; }
  .detail-table td:last-child { font-weight:700; color:#1A1A1A; }
  .footer { text-align:center; padding:20px 0 8px; font-size:12px; color:#aaa; }
  .footer a { color:${BRAND_TERRA}; }
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="card-head">
      <a href="${process.env.APP_URL || 'http://localhost:4000'}" class="brand">
        <svg class="brand-mark" viewBox="0 0 40 40" fill="none">
          <circle cx="20" cy="20" r="19" stroke="#fff" stroke-width="2"/>
          <circle cx="20" cy="20" r="13" stroke="#E8743B" stroke-width="2"/>
          <circle cx="20" cy="20" r="4" fill="#fff"/>
        </svg>
        ArtisanEye
      </a>
    </div>
    <div class="card-body">
      ${contentHtml}
    </div>
  </div>
  <div class="footer">
    © ${new Date().getFullYear()} ArtisanEye · Lagos · Abuja · Port Harcourt · Accra<br>
    <a href="${process.env.APP_URL || 'http://localhost:4000'}/privacy.html">Privacy Policy</a> ·
    <a href="${process.env.APP_URL || 'http://localhost:4000'}/terms.html">Terms of Service</a>
  </div>
</div>
</body>
</html>`;
}

// ─── Core send function ───────────────────────────────────────────────

async function sendMail({ to, subject, html, text }) {
  const transport = await getTransport();

  const info = await transport.sendMail({
    from: process.env.EMAIL_FROM || 'ArtisanEye <noreply@artisaneye.com>',
    to,
    subject,
    html,
    text: text || subject,
  });

  // In development, log the Ethereal preview URL
  const previewUrl = nodemailer.getTestMessageUrl(info);
  if (previewUrl) {
    console.log(`[mailer] Preview: ${previewUrl}`);
  }

  return info;
}

// ─── Email Templates ──────────────────────────────────────────────────

/**
 * 1. Welcome + email verification
 * Sent immediately after a new user registers.
 */
async function sendVerificationEmail({ to, fullName, verifyUrl }) {
  const html = baseTemplate('Verify your ArtisanEye email', `
    <h1>Welcome to ArtisanEye, ${fullName.split(' ')[0]}.</h1>
    <p>You're almost set. Verify your email address to activate your account and start ${
      'using the platform'
    }.</p>
    <a href="${verifyUrl}" class="btn">Verify my email</a>
    <p class="small">This link expires in 24 hours. If you didn't create an account, you can safely ignore this email.</p>
    <hr class="divider">
    <p class="small">Or copy this link into your browser:<br>${verifyUrl}</p>
  `);

  return sendMail({
    to,
    subject: 'Verify your ArtisanEye email address',
    html,
    text: `Welcome to ArtisanEye, ${fullName}! Verify your email: ${verifyUrl}`,
  });
}

/**
 * 2. Email verified confirmation
 */
async function sendWelcomeEmail({ to, fullName, role }) {
  const isArtisan = role === 'ARTISAN';
  const ctaUrl = `${process.env.APP_URL || 'http://localhost:4000'}/${isArtisan ? 'dashboard.html' : 'browse.html'}`;
  const ctaText = isArtisan ? 'Set up my profile' : 'Find an artisan';

  const html = baseTemplate('Email verified — you\'re in', `
    <h1>You're verified, ${fullName.split(' ')[0]}.</h1>
    <p>${
      isArtisan
        ? 'Your account is active. Complete your artisan profile so clients can find you.'
        : 'Your account is active. Start searching for skilled artisans near you.'
    }</p>
    <a href="${ctaUrl}" class="btn">${ctaText}</a>
    ${isArtisan ? `
    <hr class="divider">
    <p><strong>Next steps:</strong></p>
    <p>1. Add your trade and service area<br>
    2. Upload work photos<br>
    3. Submit your ID for verification</p>
    ` : ''}
  `);

  return sendMail({
    to,
    subject: 'Email verified — welcome to ArtisanEye',
    html,
    text: `You're verified, ${fullName}! Visit ${ctaUrl} to get started.`,
  });
}

/**
 * 3. Password reset
 */
async function sendPasswordResetEmail({ to, fullName, resetUrl }) {
  const html = baseTemplate('Reset your ArtisanEye password', `
    <h1>Reset your password</h1>
    <p>Hi ${fullName.split(' ')[0]}, we received a request to reset your password. Click the button below to choose a new one.</p>
    <a href="${resetUrl}" class="btn">Reset my password</a>
    <p class="small">This link expires in 1 hour. If you didn't request a password reset, you can safely ignore this email — your password won't change.</p>
    <hr class="divider">
    <p class="small">Or copy this link into your browser:<br>${resetUrl}</p>
  `);

  return sendMail({
    to,
    subject: 'Reset your ArtisanEye password',
    html,
    text: `Reset your ArtisanEye password: ${resetUrl} (expires in 1 hour)`,
  });
}

/**
 * 4. New message notification
 * Sent to the recipient when they receive a message and aren't currently online.
 */
async function sendNewMessageEmail({ to, recipientName, senderName, messagePreview, threadUrl }) {
  const html = baseTemplate(`New message from ${senderName}`, `
    <h1>You have a new message</h1>
    <p>Hi ${recipientName.split(' ')[0]}, <strong>${senderName}</strong> sent you a message on ArtisanEye.</p>
    <div style="background:${BRAND_CREAM}; border-left:3px solid ${BRAND_TERRA}; padding:14px 18px; margin:16px 0; border-radius:0 4px 4px 0; font-style:italic; color:#444;">
      "${messagePreview}${messagePreview.length >= 120 ? '…' : ''}"
    </div>
    <a href="${threadUrl}" class="btn">Reply to ${senderName}</a>
    <p class="small">You can manage email notifications from your account settings.</p>
  `);

  return sendMail({
    to,
    subject: `New message from ${senderName} — ArtisanEye`,
    html,
    text: `${senderName} sent you a message: "${messagePreview}". Reply here: ${threadUrl}`,
  });
}

/**
 * 5. Payment confirmation
 */
async function sendPaymentConfirmationEmail({ to, fullName, plan, amountNaira, reference, nextBillingDate }) {
  const dashUrl = `${process.env.APP_URL || 'http://localhost:4000'}/dashboard.html`;
  const html = baseTemplate('Payment confirmed — plan upgraded', `
    <h1>You're on the ${plan} plan 🎉</h1>
    <p>Hi ${fullName.split(' ')[0]}, your payment was successful and your profile has been upgraded.</p>
    <table class="detail-table">
      <tr><td>Plan</td><td>${plan}</td></tr>
      <tr><td>Amount paid</td><td>₦${amountNaira.toLocaleString()}</td></tr>
      <tr><td>Reference</td><td>${reference}</td></tr>
      <tr><td>Next billing date</td><td>${nextBillingDate}</td></tr>
    </table>
    <a href="${dashUrl}" class="btn">View my dashboard</a>
    <hr class="divider">
    <p class="small">Keep this email as your receipt. To cancel your subscription, go to Account → Billing in your dashboard.</p>
  `);

  return sendMail({
    to,
    subject: `Payment confirmed — you're on the ${plan} plan`,
    html,
    text: `Payment confirmed. Plan: ${plan}, Amount: ₦${amountNaira}, Ref: ${reference}. Visit ${dashUrl}`,
  });
}

/**
 * 6. Subscription cancelled
 */
async function sendSubscriptionCancelledEmail({ to, fullName, plan, activeUntil }) {
  const pricingUrl = `${process.env.APP_URL || 'http://localhost:4000'}/pricing.html`;
  const html = baseTemplate('Subscription cancelled', `
    <h1>Your ${plan} subscription has been cancelled</h1>
    <p>Hi ${fullName.split(' ')[0]}, we've processed your cancellation request.</p>
    <table class="detail-table">
      <tr><td>Plan</td><td>${plan}</td></tr>
      <tr><td>Status</td><td>Cancelled</td></tr>
      <tr><td>Access until</td><td>${activeUntil}</td></tr>
    </table>
    <p>You'll keep ${plan} features until <strong>${activeUntil}</strong>, then your profile will move back to the Starter plan automatically.</p>
    <a href="${pricingUrl}" class="btn-ghost">View plans</a>
  `);

  return sendMail({
    to,
    subject: `Your ArtisanEye ${plan} subscription has been cancelled`,
    html,
    text: `Your ${plan} subscription is cancelled. You have access until ${activeUntil}.`,
  });
}

/**
 * 7. Artisan verification approved
 */
async function sendVerificationApprovedEmail({ to, fullName }) {
  const profileUrl = `${process.env.APP_URL || 'http://localhost:4000'}/dashboard.html`;
  const html = baseTemplate('You\'re verified on ArtisanEye', `
    <h1>Your profile is now verified ✓</h1>
    <p>Hi ${fullName.split(' ')[0]}, great news — our team has reviewed your documents and your profile is now verified.</p>
    <p>What this means for you:</p>
    <ul style="color:#3c3c3c; font-size:15px; line-height:1.8; margin:0 0 20px; padding-left:20px;">
      <li>The verified badge appears on your profile</li>
      <li>You rank higher in search results</li>
      <li>Clients see your profile as more trustworthy</li>
    </ul>
    <a href="${profileUrl}" class="btn">View my profile</a>
  `);

  return sendMail({
    to,
    subject: 'Your ArtisanEye profile is now verified',
    html,
    text: `Your ArtisanEye profile is verified! View it here: ${profileUrl}`,
  });
}

/**
 * 8. Artisan verification rejected
 */
async function sendVerificationRejectedEmail({ to, fullName, reason }) {
  const supportUrl = `${process.env.APP_URL || 'http://localhost:4000'}/contact.html`;
  const html = baseTemplate('Verification update', `
    <h1>We couldn't verify your profile</h1>
    <p>Hi ${fullName.split(' ')[0]}, we reviewed your verification submission but weren't able to approve it.</p>
    ${reason ? `
    <div style="background:#fff5f5; border-left:3px solid #B5402C; padding:14px 18px; margin:16px 0; border-radius:0 4px 4px 0; color:#5a2020;">
      <strong>Reason:</strong> ${reason}
    </div>
    ` : ''}
    <p>You're welcome to resubmit with updated documents. If you think this is a mistake, contact our support team.</p>
    <a href="${supportUrl}" class="btn-ghost">Contact support</a>
  `);

  return sendMail({
    to,
    subject: 'Update on your ArtisanEye verification',
    html,
    text: `We couldn't verify your profile. Reason: ${reason || 'See email for details'}. Contact support: ${supportUrl}`,
  });
}

module.exports = {
  sendMail,
  sendVerificationEmail,
  sendWelcomeEmail,
  sendPasswordResetEmail,
  sendNewMessageEmail,
  sendPaymentConfirmationEmail,
  sendSubscriptionCancelledEmail,
  sendVerificationApprovedEmail,
  sendVerificationRejectedEmail,
};
