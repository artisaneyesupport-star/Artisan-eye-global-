/**
 * Paystack API utility
 * Thin wrapper around Paystack REST endpoints.
 * Docs: https://paystack.com/docs/api/
 */

const https = require('https');

const BASE = 'api.paystack.co';

function paystackRequest(method, path, body = null) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;

    const options = {
      hostname: BASE,
      port: 443,
      path,
      method,
      headers: {
        Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
        'Content-Type': 'application/json',
        ...(payload ? { 'Content-Length': Buffer.byteLength(payload) } : {}),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          reject(new Error('Paystack returned non-JSON response.'));
        }
      });
    });

    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// ─── Initialize transaction ───────────────────────────────────────────
/**
 * Creates a Paystack checkout URL.
 * @param {string} email       - Customer email
 * @param {number} amountKobo  - Amount in kobo (e.g. 450000 = ₦4,500)
 * @param {string} reference   - Unique reference for this payment
 * @param {string} plan        - Paystack plan code (for subscriptions)
 * @param {object} metadata    - Extra data stored on the transaction
 */
async function initializeTransaction({ email, amountKobo, reference, plan, metadata = {} }) {
  return paystackRequest('POST', '/transaction/initialize', {
    email,
    amount: amountKobo,
    reference,
    plan,
    callback_url: process.env.PAYMENT_CALLBACK_URL,
    metadata,
  });
}

// ─── Verify transaction ───────────────────────────────────────────────
async function verifyTransaction(reference) {
  return paystackRequest('GET', `/transaction/verify/${encodeURIComponent(reference)}`);
}

// ─── Create/fetch customer ────────────────────────────────────────────
async function createCustomer({ email, firstName, lastName, phone }) {
  return paystackRequest('POST', '/customer', {
    email,
    first_name: firstName,
    last_name: lastName,
    phone,
  });
}

// ─── List customer subscriptions ─────────────────────────────────────
async function listSubscriptions(customerCode) {
  return paystackRequest('GET', `/subscription?customer=${customerCode}`);
}

// ─── Cancel (disable) subscription ───────────────────────────────────
async function cancelSubscription(subscriptionCode, emailToken) {
  return paystackRequest('POST', '/subscription/disable', {
    code: subscriptionCode,
    token: emailToken,
  });
}

// ─── Verify webhook signature ─────────────────────────────────────────
function verifyWebhookSignature(rawBody, paystackSignature) {
  const crypto = require('crypto');
  const hash = crypto
    .createHmac('sha512', process.env.PAYSTACK_WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');
  return hash === paystackSignature;
}

// ─── Plan code helpers ────────────────────────────────────────────────
const PLAN_CODES = {
  PRO:  () => process.env.PAYSTACK_PLAN_PRO,
  TEAM: () => process.env.PAYSTACK_PLAN_TEAM,
};

// Monthly amounts in kobo
const PLAN_AMOUNTS = {
  PRO:  450000,   // ₦4,500
  TEAM: 1200000,  // ₦12,000
};

module.exports = {
  initializeTransaction,
  verifyTransaction,
  createCustomer,
  listSubscriptions,
  cancelSubscription,
  verifyWebhookSignature,
  PLAN_CODES,
  PLAN_AMOUNTS,
};
