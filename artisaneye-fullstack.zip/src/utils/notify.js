const prisma = require('../config/prisma');

/**
 * notifyUser — creates an in-app Notification row and, if a Socket.io
 * instance is passed, pushes it in real time to the user's personal room
 * (joined as `user:<id>` — see src/index.js socket auth middleware).
 *
 * Non-throwing by design: a notification failure should never break the
 * job/message/admin action that triggered it, so errors are logged only.
 *
 * @param {object} params
 * @param {string} params.userId - recipient
 * @param {'MESSAGE'|'JOB_UPDATE'|'VERIFICATION'|'SYSTEM'} params.type
 * @param {string} params.title
 * @param {string} params.body
 * @param {string} [params.link] - e.g. a job id or thread id for deep-linking
 * @param {import('socket.io').Server} [io]
 */
async function notifyUser({ userId, type, title, body, link }, io) {
  try {
    const notification = await prisma.notification.create({
      data: { userId, type, title, body, link: link || null },
    });

    if (io) {
      io.to(`user:${userId}`).emit('notification:new', notification);
    }

    return notification;
  } catch (err) {
    console.warn('[notify] failed to create notification:', err.message);
    return null;
  }
}

module.exports = { notifyUser };
