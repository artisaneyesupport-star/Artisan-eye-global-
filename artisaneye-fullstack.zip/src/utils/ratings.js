/**
 * ratings.js
 * ===========
 * Shared utility for recalculating an artisan's average rating.
 * Used by job.controller.js after a review is submitted.
 */

const prisma = require('../config/prisma');

/**
 * Recalculates and persists the average rating + job count
 * for an artisan profile based on all their reviews.
 * @param {string} artisanProfileId
 */
async function recalcRating(artisanProfileId) {
  const agg = await prisma.review.aggregate({
    where: { artisanProfileId },
    _avg:   { rating: true },
    _count: { rating: true },
  });

  await prisma.artisanProfile.update({
    where: { id: artisanProfileId },
    data: {
      rating:        parseFloat((agg._avg.rating || 0).toFixed(2)),
      jobsCompleted: agg._count.rating,
    },
  });
}

module.exports = { recalcRating };
