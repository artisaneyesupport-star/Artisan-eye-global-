/**
 * cloudinary.js
 * ==============
 * Cloudinary upload utility for work photos.
 * Replaces local disk storage from upload.js.
 *
 * Setup:
 *   npm install cloudinary multer-storage-cloudinary
 *
 *   Add to .env:
 *     CLOUDINARY_CLOUD_NAME=your_cloud_name
 *     CLOUDINARY_API_KEY=your_api_key
 *     CLOUDINARY_API_SECRET=your_api_secret
 *
 * Usage in controller:
 *   const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');
 *   const result = await uploadToCloudinary(file.buffer, { folder: 'artisaneye/photos' });
 *   // result.url      — HTTPS URL to use in DB
 *   // result.publicId — store this to delete later
 */

const cloudinary = require('cloudinary').v2;
const multer     = require('multer');
const { Readable } = require('stream');

// Configure from env
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure:     true,
});

// ─── Upload ───────────────────────────────────────────────────────────

/**
 * Uploads a file buffer to Cloudinary.
 * @param {Buffer} buffer   - File data from multer memoryStorage
 * @param {object} options  - Cloudinary upload options (folder, transformation, etc.)
 * @returns {{ url, publicId, width, height, format }}
 */
function uploadToCloudinary(buffer, options = {}) {
  return new Promise((resolve, reject) => {
    const uploadOptions = {
      folder:           'artisaneye/photos',
      resource_type:    'image',
      transformation:   [
        { width: 1200, height: 900, crop: 'limit', quality: 'auto:good' },
        { fetch_format: 'auto' }, // serve WebP to browsers that support it
      ],
      ...options,
    };

    const uploadStream = cloudinary.uploader.upload_stream(
      uploadOptions,
      (error, result) => {
        if (error) return reject(error);
        resolve({
          url:      result.secure_url,
          publicId: result.public_id,
          width:    result.width,
          height:   result.height,
          format:   result.format,
        });
      }
    );

    // Pipe buffer into the upload stream
    const readable = new Readable();
    readable.push(buffer);
    readable.push(null);
    readable.pipe(uploadStream);
  });
}

// ─── Delete ───────────────────────────────────────────────────────────

/**
 * Deletes an image from Cloudinary by its public_id.
 * @param {string} publicId
 */
async function deleteFromCloudinary(publicId) {
  if (!publicId) return;
  return cloudinary.uploader.destroy(publicId);
}

// ─── Multer (memory storage) ──────────────────────────────────────────
// Files land in memory as buffer, then we stream to Cloudinary.

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_SIZE      = 5 * 1024 * 1024; // 5 MB

const uploadMiddleware = multer({
  storage: multer.memoryStorage(),
  fileFilter: (req, file, cb) => {
    if (ALLOWED_TYPES.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only JPEG, PNG, and WebP images are allowed.'), false);
  },
  limits: { fileSize: MAX_SIZE },
});

module.exports = { uploadToCloudinary, deleteFromCloudinary, uploadMiddleware };
