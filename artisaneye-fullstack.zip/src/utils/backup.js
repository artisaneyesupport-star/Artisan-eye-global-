/**
 * backup.js
 * ==========
 * Automated PostgreSQL backup.
 *
 * Storage strategy (in priority order):
 *   1. If BACKUP_DIR env var is set → write to that path (VPS/DigitalOcean)
 *   2. If Cloudinary is configured → upload dump as a raw file to Cloudinary
 *   3. Otherwise → log a warning and skip (Railway ephemeral filesystem loses files on redeploy)
 *
 * Railway users: enable Railway's built-in backup feature in your PostgreSQL
 * service settings instead of relying on this script.
 *
 * Setup:
 *   No extra packages needed — uses Cloudinary (already installed) or local fs.
 *
 * Usage:
 *   node src/utils/backup.js        ← run manually
 *   Called automatically by cron at 03:00 WAT
 */

const { execSync } = require('child_process');
const path         = require('path');
const fs           = require('fs');

const DATABASE_URL = process.env.DATABASE_URL;
const BACKUP_DIR   = process.env.BACKUP_DIR; // Only set on VPS — not Railway
const KEEP_DAYS    = parseInt(process.env.BACKUP_KEEP_DAYS || '7', 10);

// ─── Helpers ──────────────────────────────────────────────────────────

function timestamp() {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

function isPgDumpAvailable() {
  try { execSync('which pg_dump', { stdio: 'pipe' }); return true; }
  catch { return false; }
}

// ─── Strategy 1: Local disk (VPS / DigitalOcean) ──────────────────────

async function backupToLocalDisk() {
  if (!fs.existsSync(BACKUP_DIR)) {
    fs.mkdirSync(BACKUP_DIR, { recursive: true });
  }
  const filename = `artisaneye-backup-${timestamp()}.sql`;
  const filepath = path.join(BACKUP_DIR, filename);

  execSync(
    `pg_dump "${DATABASE_URL}" --no-password --format=plain --file="${filepath}"`,
    { stdio: 'pipe', timeout: 5 * 60 * 1000 }
  );

  const sizeMB = (fs.statSync(filepath).size / 1024 / 1024).toFixed(2);
  pruneLocalBackups();
  return { filename, sizeMB, storage: 'local', path: filepath };
}

function pruneLocalBackups() {
  const cutoff = Date.now() - KEEP_DAYS * 24 * 60 * 60 * 1000;
  let pruned = 0;
  try {
    fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('artisaneye-backup-') && f.endsWith('.sql'))
      .forEach(f => {
        const fp = path.join(BACKUP_DIR, f);
        if (fs.statSync(fp).mtimeMs < cutoff) { fs.unlinkSync(fp); pruned++; }
      });
    if (pruned > 0) console.log(`[backup] Pruned ${pruned} old backup(s)`);
  } catch (e) { console.warn('[backup] Prune failed:', e.message); }
}

// ─── Strategy 2: Cloudinary raw upload ────────────────────────────────

async function backupToCloudinary() {
  const cloudinary = require('cloudinary').v2;
  const { Readable } = require('stream');

  // pg_dump to buffer via stdout
  const sql = execSync(
    `pg_dump "${DATABASE_URL}" --no-password --format=plain`,
    { maxBuffer: 100 * 1024 * 1024, timeout: 5 * 60 * 1000 } // 100MB max
  );

  const filename = `artisaneye-backup-${timestamp()}.sql`;

  return new Promise((resolve, reject) => {
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder:        'artisaneye/backups',
        public_id:     filename.replace('.sql', ''),
        resource_type: 'raw',
        format:        'sql',
      },
      (error, result) => {
        if (error) return reject(error);
        resolve({
          filename,
          sizeMB:  (sql.length / 1024 / 1024).toFixed(2),
          storage: 'cloudinary',
          url:     result.secure_url,
          publicId: result.public_id,
        });
      }
    );

    const readable = new Readable();
    readable.push(sql);
    readable.push(null);
    readable.pipe(uploadStream);
  });
}

function isCloudinaryConfigured() {
  return !!(
    process.env.CLOUDINARY_CLOUD_NAME &&
    process.env.CLOUDINARY_API_KEY &&
    process.env.CLOUDINARY_API_SECRET
  );
}

// ─── Main ─────────────────────────────────────────────────────────────

async function runBackup() {
  if (!DATABASE_URL) {
    console.warn('[backup] DATABASE_URL not set — skipping');
    return { success: false, reason: 'no DATABASE_URL' };
  }

  if (!isPgDumpAvailable()) {
    console.warn('[backup] pg_dump not found in PATH — skipping');
    return { success: false, reason: 'pg_dump not available' };
  }

  try {
    let result;

    if (BACKUP_DIR) {
      // VPS/DigitalOcean: write to local disk
      console.log('[backup] Strategy: local disk →', BACKUP_DIR);
      result = await backupToLocalDisk();
    } else if (isCloudinaryConfigured()) {
      // Railway/Render: upload to Cloudinary as raw file
      console.log('[backup] Strategy: Cloudinary raw upload');
      result = await backupToCloudinary();
    } else {
      // No persistent storage available
      console.warn('[backup] ⚠️  No persistent storage configured.');
      console.warn('[backup]    On Railway: enable built-in backups in your PostgreSQL service settings.');
      console.warn('[backup]    On VPS: set BACKUP_DIR=/path/to/backups in your .env');
      console.warn('[backup]    Alternatively: ensure Cloudinary env vars are set.');
      return { success: false, reason: 'no persistent storage configured' };
    }

    console.log(`[backup] ✓ Backup complete: ${result.filename} (${result.sizeMB} MB) → ${result.storage}`);
    return { success: true, ...result };
  } catch (err) {
    console.error('[backup] ✗ Backup failed:', err.message);
    return { success: false, error: err.message };
  }
}

function listBackups() {
  // Only works for local disk strategy
  if (!BACKUP_DIR || !fs.existsSync(BACKUP_DIR)) return [];
  return fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('artisaneye-backup-') && f.endsWith('.sql'))
    .map(f => {
      const stats = fs.statSync(path.join(BACKUP_DIR, f));
      return { name: f, sizeMB: (stats.size / 1024 / 1024).toFixed(2), created: stats.mtime };
    })
    .sort((a, b) => new Date(b.created) - new Date(a.created));
}

module.exports = { runBackup, listBackups };

// Run directly: node src/utils/backup.js
if (require.main === module) {
  runBackup().then(r => { if (!r.success) process.exit(1); });
}
