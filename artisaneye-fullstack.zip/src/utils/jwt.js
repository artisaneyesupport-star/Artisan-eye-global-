const jwt = require('jsonwebtoken');

// ─── Access Token ──────────────────────────────────────────────────────
// Short-lived (15 min). Sent in Authorization header: Bearer <token>

function signAccessToken(payload) {
  return jwt.sign(payload, process.env.JWT_ACCESS_SECRET, {
    expiresIn: process.env.JWT_ACCESS_EXPIRES_IN || '15m',
  });
}

function verifyAccessToken(token) {
  return jwt.verify(token, process.env.JWT_ACCESS_SECRET);
}

// ─── Refresh Token ─────────────────────────────────────────────────────
// Long-lived (7 days). Stored in DB + sent as HttpOnly cookie.
// Used to silently issue new access tokens without re-login.

function signRefreshToken(payload) {
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  });
}

function verifyRefreshToken(token) {
  return jwt.verify(token, process.env.JWT_REFRESH_SECRET);
}

module.exports = {
  signAccessToken,
  verifyAccessToken,
  signRefreshToken,
  verifyRefreshToken,
};
