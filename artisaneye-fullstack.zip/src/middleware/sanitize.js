/**
 * sanitize.js
 * ============
 * Recursively strips HTML tags from every string value in req.body
 * before it reaches controllers or the database.
 *
 * Uses a simple regex rather than a full DOM parser — sufficient for
 * text fields like bio, comment, subject. For rich-text fields you
 * should use the `sanitize-html` npm package instead.
 *
 * Applied globally in app.js so no controller needs to remember it.
 */

function stripHtml(value) {
  if (typeof value !== 'string') return value;
  return value
    .replace(/<[^>]*>/g, '')       // remove all HTML tags
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .trim();
}

function sanitizeObject(obj) {
  if (obj === null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(sanitizeObject);
  const out = {};
  for (const [key, value] of Object.entries(obj)) {
    out[key] = typeof value === 'string'
      ? stripHtml(value)
      : sanitizeObject(value);
  }
  return out;
}

/**
 * sanitizeBody — Express middleware.
 * Mutates req.body in-place so all downstream handlers get clean data.
 */
function sanitizeBody(req, res, next) {
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeObject(req.body);
  }
  next();
}

module.exports = { sanitizeBody, stripHtml };
