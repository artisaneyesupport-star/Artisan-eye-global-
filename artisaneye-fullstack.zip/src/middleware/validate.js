const { validationResult, body } = require('express-validator');
const { badRequest } = require('../utils/response');

/**
 * validate — runs after express-validator chains.
 * If errors exist, returns 400 with formatted error list.
 */
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return badRequest(res, 'Validation failed', errors.array().map(e => ({
      field: e.path,
      message: e.msg,
    })));
  }
  next();
}

// ─── Reusable validation rule chains ──────────────────────────────────

const registerRules = [
  body('fullName')
    .trim()
    .notEmpty().withMessage('Full name is required.')
    .isLength({ min: 2, max: 80 }).withMessage('Full name must be 2–80 characters.'),

  body('email')
    .trim()
    .notEmpty().withMessage('Email is required.')
    .isEmail().withMessage('Must be a valid email address.')
    .normalizeEmail(),

  body('password')
    .notEmpty().withMessage('Password is required.')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters.')
    .matches(/[A-Z]/).withMessage('Password must contain at least one uppercase letter.')
    .matches(/[0-9]/).withMessage('Password must contain at least one number.'),

  body('role')
    .optional()
    .isIn(['CLIENT', 'ARTISAN']).withMessage('Role must be CLIENT or ARTISAN.'),

  body('phone')
    .optional()
    .isMobilePhone().withMessage('Must be a valid phone number.'),
];

const loginRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required.')
    .isEmail().withMessage('Must be a valid email address.')
    .normalizeEmail(),

  body('password')
    .notEmpty().withMessage('Password is required.'),
];

module.exports = { validate, registerRules, loginRules };
