/**
 * security.js
 * ============
 * Production-grade security middleware:
 *
 *  1. HTTPS redirect — forces HTTP → HTTPS in production
 *  2. HSTS header — tells browsers to only use HTTPS for 1 year
 *  3. Hide X-Powered-By (already done by helmet, kept explicit here)
 *  4. Referrer Policy
 *
 * Use in app.js BEFORE any routes:
 *   const { httpsRedirect, securityHeaders } = require('./middleware/security');
 *   app.use(httpsRedirect);
 *   app.use(securityHeaders);
 */

/**
 * httpsRedirect
 * Redirects HTTP requests to HTTPS in production.
 * Trusts proxy headers (X-Forwarded-Proto) set by Nginx / Railway / Render.
 */
function httpsRedirect(req, res, next) {
  if (process.env.NODE_ENV !== 'production') return next();

  const proto = req.headers['x-forwarded-proto'] || req.protocol;
  if (proto === 'https') return next();

  const httpsUrl = `https://${req.headers.host}${req.originalUrl}`;
  return res.redirect(301, httpsUrl);
}

/**
 * securityHeaders
 * Adds production-grade HTTP security headers not covered by helmet defaults.
 */
function securityHeaders(req, res, next) {
  if (process.env.NODE_ENV === 'production') {
    // Tell browsers to only use HTTPS for the next year
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  }

  // Prevent MIME type sniffing (also set by helmet, explicit here for clarity)
  res.setHeader('X-Content-Type-Options', 'nosniff');

  // Only send minimal referrer info to third-party sites
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  // Disable browser features not used by the API
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');

  next();
}

/**
 * trustProxy
 * Call app.set('trust proxy', 1) in app.js when behind a reverse proxy
 * (Nginx, Railway, Render, etc.) so req.ip and req.protocol work correctly.
 * This function is exported as a reminder; apply it directly in app.js.
 */
const TRUST_PROXY = 1;

module.exports = { httpsRedirect, securityHeaders, TRUST_PROXY };
