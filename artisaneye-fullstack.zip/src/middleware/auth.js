const { verifyAccessToken } = require('../utils/jwt');
const { unauthorized, forbidden } = require('../utils/response');

/**
 * authenticate — verifies the Bearer access token on protected routes.
 * Attaches decoded user payload to req.user on success.
 */
function authenticate(req, res, next) {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return unauthorized(res, 'Missing or malformed Authorization header.');
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = verifyAccessToken(token);
    req.user = decoded; // { id, email, role, iat, exp }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return unauthorized(res, 'Access token expired. Please refresh.');
    }
    return unauthorized(res, 'Invalid access token.');
  }
}

/**
 * requireRole(...roles) — role-based access guard.
 * Must be used AFTER authenticate.
 *
 * Usage: router.get('/admin', authenticate, requireRole('ADMIN'), handler)
 */
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return unauthorized(res);
    if (!roles.includes(req.user.role)) {
      return forbidden(res, `This endpoint requires one of: ${roles.join(', ')}`);
    }
    next();
  };
}

module.exports = { authenticate, requireRole };
