/**
 * userRateLimit.js
 * =================
 * Per-user rate limiting — keys on authenticated user ID rather than IP.
 * Use this on expensive or abuse-prone endpoints (search, messaging, uploads).
 *
 * Usage:
 *   router.get('/artisans', userRateLimit(60, 30), getAll);
 *   // max 30 requests per 60 seconds per user
 */

const rateLimit = require('express-rate-limit');

/**
 * userRateLimit(windowSeconds, max)
 * Returns a rate-limit middleware keyed to req.user.id (falls back to IP).
 *
 * @param {number} windowSeconds - Time window in seconds
 * @param {number} max           - Max requests per window
 */
function userRateLimit(windowSeconds = 60, max = 60) {
  return rateLimit({
    windowMs: windowSeconds * 1000,
    max,
    keyGenerator: (req) => req.user?.id || req.ip,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      success: false,
      message: `Too many requests. Please slow down — limit is ${max} per ${windowSeconds}s.`,
    },
    skip: (req) => {
      // Never rate-limit admins
      return req.user?.role === 'ADMIN';
    },
  });
}

module.exports = userRateLimit;
