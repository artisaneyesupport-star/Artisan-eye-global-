const prisma = require('../config/prisma');
const { uploadToCloudinary, deleteFromCloudinary } = require('../utils/cloudinary');
const { ok, badRequest, forbidden, notFound } = require('../utils/response');

const MAX_PHOTOS = { STARTER: 5, PRO: 20, TEAM: 20 };

// ─── GET /api/artisans/me ─────────────────────────────────────────────
// Returns the authenticated artisan's full private profile

async function getMe(req, res, next) {
  try {
    const profile = await prisma.artisanProfile.findUnique({
      where: { userId: req.user.id },
      include: { photos: true, reviews: { orderBy: { createdAt: 'desc' }, take: 5 } },
    });
    if (!profile) return notFound(res, 'Artisan profile not found. Are you registered as an artisan?');
    return ok(res, { profile });
  } catch (err) { next(err); }
}

// ─── PATCH /api/artisans/me ───────────────────────────────────────────
// Update the authenticated artisan's own profile

async function updateMe(req, res, next) {
  try {
    const { trade, city, bio, yearsExperience, startingRate, languages, serviceArea } = req.body;

    const existing = await prisma.artisanProfile.findUnique({ where: { userId: req.user.id } });
    if (!existing) return notFound(res, 'Artisan profile not found.');

    const profile = await prisma.artisanProfile.update({
      where: { userId: req.user.id },
      data: {
        ...(trade !== undefined && { trade: Array.isArray(trade) ? trade : [trade] }),
        ...(city !== undefined && { city }),
        ...(bio !== undefined && { bio }),
        ...(yearsExperience !== undefined && { yearsExperience: parseInt(yearsExperience) }),
        ...(startingRate !== undefined && { startingRate }),
        ...(languages !== undefined && { languages: Array.isArray(languages) ? languages : [languages] }),
        ...(serviceArea !== undefined && { serviceArea }),
      },
      include: { photos: true },
    });

    return ok(res, { profile }, 'Profile updated.');
  } catch (err) { next(err); }
}

// ─── GET /api/artisans ────────────────────────────────────────────────
// Public search endpoint with filters, sorting, pagination

async function getAll(req, res, next) {
  try {
    const {
      trade,
      city,
      verified,           // "true" | "false"
      minRating,          // e.g. "4.5"
      plan,               // "PRO" | "TEAM"
      search,             // searches name + bio
      sortBy = 'rating',  // "rating" | "jobs" | "newest"
      page = '1',
      limit = '12',
    } = req.query;

    const pageNum  = Math.max(1, parseInt(page));
    const pageSize = Math.min(50, Math.max(1, parseInt(limit)));
    const skip = (pageNum - 1) * pageSize;

    // Build Prisma where clause
    const where = {};

    if (trade) {
      where.trade = { has: trade };
    }
    if (city) {
      where.city = { contains: city, mode: 'insensitive' };
    }
    if (verified === 'true') {
      where.verificationStatus = 'VERIFIED';
    }
    if (minRating) {
      where.rating = { gte: parseFloat(minRating) };
    }
    if (plan) {
      where.plan = plan.toUpperCase();
    }
    if (search) {
      // Match on artisan name, bio, OR trade — any one hit counts, combined
      // with an AND against whatever other filters (trade/city/etc) are set.
      where.OR = [
        { user: { fullName: { contains: search, mode: 'insensitive' } } },
        { bio: { contains: search, mode: 'insensitive' } },
        { trade: { hasSome: [search] } },
      ];
    }

    // Build orderBy
    const orderBy =
      sortBy === 'jobs'   ? { jobsCompleted: 'desc' } :
      sortBy === 'newest' ? { createdAt: 'desc' } :
                            { rating: 'desc' };

    const [artisans, total] = await Promise.all([
      prisma.artisanProfile.findMany({
        where,
        orderBy,
        skip,
        take: pageSize,
        include: {
          user: { select: { id: true, fullName: true, avatarUrl: true } },
          photos: { take: 1, orderBy: { createdAt: 'asc' } }, // cover photo
        },
      }),
      prisma.artisanProfile.count({ where }),
    ]);

    return ok(res, {
      artisans,
      pagination: {
        page: pageNum,
        limit: pageSize,
        total,
        pages: Math.ceil(total / pageSize),
      },
    });
  } catch (err) { next(err); }
}

// ─── GET /api/artisans/:id ────────────────────────────────────────────
// Full public profile for a single artisan

async function getById(req, res, next) {
  try {
    const { id } = req.params;

    const profile = await prisma.artisanProfile.findUnique({
      where: { id },
      include: {
        user: { select: { id: true, fullName: true, avatarUrl: true, createdAt: true } },
        photos: { orderBy: { createdAt: 'asc' } },
        reviews: {
          orderBy: { createdAt: 'desc' },
          take: 20,
        },
      },
    });

    if (!profile) return notFound(res, 'Artisan not found.');
    return ok(res, { profile });
  } catch (err) { next(err); }
}

// ─── POST /api/artisans/me/photos ─────────────────────────────────────
// Upload one or more work photos (multipart/form-data, field: "photos")

async function addPhotos(req, res, next) {
  try {
    const profile = await prisma.artisanProfile.findUnique({
      where: { userId: req.user.id },
      include: { photos: true },
    });
    if (!profile) return notFound(res, 'Artisan profile not found.');

    const limit     = MAX_PHOTOS[profile.plan] || 5;
    const remaining = limit - profile.photos.length;

    if (remaining <= 0) {
      return badRequest(res, `You've reached the ${limit}-photo limit for your ${profile.plan} plan. Upgrade to add more.`);
    }

    if (!req.files || req.files.length === 0) {
      return badRequest(res, 'No files uploaded. Send files under the field name "photos".');
    }

    const toAdd  = req.files.slice(0, remaining);
    const caption = req.body.caption || null;

    // Upload each file to Cloudinary in parallel
    const uploadResults = await Promise.all(
      toAdd.map(file => uploadToCloudinary(file.buffer, {
        folder:  `artisaneye/${profile.id}`,
        caption,
      }))
    );

    // Persist URLs + public IDs to DB
    const photos = await Promise.all(
      uploadResults.map(result =>
        prisma.workPhoto.create({
          data: {
            artisanProfileId: profile.id,
            url:      result.url,
            publicId: result.publicId,
            caption,
          },
        })
      )
    );

    return ok(res, { photos }, `${photos.length} photo(s) uploaded.`);
  } catch (err) { next(err); }
}

// ─── DELETE /api/artisans/me/photos/:photoId ──────────────────────────

async function deletePhoto(req, res, next) {
  try {
    const { photoId } = req.params;

    const profile = await prisma.artisanProfile.findUnique({ where: { userId: req.user.id } });
    if (!profile) return notFound(res, 'Artisan profile not found.');

    const photo = await prisma.workPhoto.findUnique({ where: { id: photoId } });
    if (!photo) return notFound(res, 'Photo not found.');
    if (photo.artisanProfileId !== profile.id) return forbidden(res, 'This photo does not belong to your profile.');

    // Delete from Cloudinary if we have a public_id
    if (photo.publicId) {
      await deleteFromCloudinary(photo.publicId);
    }

    await prisma.workPhoto.delete({ where: { id: photoId } });
    return ok(res, {}, 'Photo deleted.');
  } catch (err) { next(err); }
}

module.exports = { getMe, updateMe, getAll, getById, addPhotos, deletePhoto };
