const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const prisma = require('../config/prisma');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const { sendVerificationEmail } = require('../utils/mailer');
const { ok, created, unauthorized, conflict } = require('../utils/response');

// ─── Helpers ──────────────────────────────────────────────────────────

const REFRESH_TOKEN_COOKIE = 'refreshToken';

function setRefreshCookie(res, token) {
  res.cookie(REFRESH_TOKEN_COOKIE, token, {
    httpOnly: true,        // not accessible via JS — protects against XSS
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days in ms
  });
}

function clearRefreshCookie(res) {
  res.clearCookie(REFRESH_TOKEN_COOKIE);
}

function safeUser(user) {
  // Never send passwordHash to client
  const { passwordHash, ...safe } = user;
  return safe;
}

// ─── Register ─────────────────────────────────────────────────────────

async function register(req, res, next) {
  try {
    const { fullName, email, password, role = 'CLIENT', phone } = req.body;

    // Check duplicate email
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) return conflict(res, 'An account with that email already exists.');

    const passwordHash = await bcrypt.hash(password, 12);

    // Build create payload — artisans get an empty profile scaffold
    const createData = {
      fullName,
      email,
      passwordHash,
      role,
      phone: phone || null,
      ...(role === 'ARTISAN' && {
        artisanProfile: {
          create: {
            trade: [],
            city: '',
          },
        },
      }),
    };

    const user = await prisma.user.create({
      data: createData,
      include: { artisanProfile: true },
    });

    // Issue tokens immediately so the user is logged in after signup
    const accessToken = signAccessToken({ id: user.id, email: user.email, role: user.role });
    const refreshToken = signRefreshToken({ id: user.id });

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await prisma.refreshToken.create({
      data: { token: refreshToken, userId: user.id, expiresAt },
    });

    setRefreshCookie(res, refreshToken);

    // Fire verification email (non-blocking — don't fail registration if email fails)
    try {
      const verifyToken  = crypto.randomBytes(32).toString('hex');
      const expiresAt    = new Date(Date.now() + 24 * 60 * 60 * 1000);
      await prisma.emailVerification.create({
        data: { userId: user.id, token: verifyToken, expiresAt },
      });
      const verifyUrl = `${process.env.APP_URL || 'http://localhost:4000'}/verify-email.html?token=${verifyToken}`;
      await sendVerificationEmail({ to: user.email, fullName: user.fullName, verifyUrl });
    } catch (emailErr) {
      console.warn('[auth] Could not send verification email:', emailErr.message);
    }

    return created(res, { accessToken, user: safeUser(user) }, 'Account created successfully.');
  } catch (err) {
    next(err);
  }
}

// ─── Login ────────────────────────────────────────────────────────────

async function login(req, res, next) {
  try {
    const { email, password } = req.body;

    const user = await prisma.user.findUnique({
      where: { email },
      include: { artisanProfile: true },
    });

    // Deliberately vague error — don't reveal whether email exists
    if (!user) return unauthorized(res, 'Invalid email or password.');

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return unauthorized(res, 'Invalid email or password.');

    // Enforce email verification before allowing access
    if (!user.emailVerified) {
      return res.status(403).json({
        success: false,
        code: 'EMAIL_NOT_VERIFIED',
        message: 'Please verify your email before logging in. Check your inbox or request a new verification link.',
      });
    }

    const accessToken = signAccessToken({ id: user.id, email: user.email, role: user.role });
    const refreshToken = signRefreshToken({ id: user.id });

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await prisma.refreshToken.create({
      data: { token: refreshToken, userId: user.id, expiresAt },
    });

    setRefreshCookie(res, refreshToken);

    return ok(res, { accessToken, user: safeUser(user) }, 'Logged in successfully.');
  } catch (err) {
    next(err);
  }
}

// ─── Refresh ──────────────────────────────────────────────────────────
// Issues a new access token using the refresh token stored in HttpOnly cookie.

async function refresh(req, res, next) {
  try {
    const token = req.cookies?.[REFRESH_TOKEN_COOKIE];
    if (!token) return unauthorized(res, 'No refresh token found.');

    // Verify JWT signature
    let payload;
    try {
      payload = verifyRefreshToken(token);
    } catch {
      return unauthorized(res, 'Invalid or expired refresh token. Please log in again.');
    }

    // Check token exists in DB and isn't revoked
    const stored = await prisma.refreshToken.findUnique({ where: { token } });
    if (!stored || stored.revoked || stored.expiresAt < new Date()) {
      clearRefreshCookie(res);
      return unauthorized(res, 'Refresh token is invalid. Please log in again.');
    }

    const user = await prisma.user.findUnique({ where: { id: payload.id } });
    if (!user) return unauthorized(res, 'User no longer exists.');

    // Rotate: revoke old token, issue new pair
    await prisma.refreshToken.update({ where: { token }, data: { revoked: true } });

    const newAccessToken = signAccessToken({ id: user.id, email: user.email, role: user.role });
    const newRefreshToken = signRefreshToken({ id: user.id });

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await prisma.refreshToken.create({
      data: { token: newRefreshToken, userId: user.id, expiresAt },
    });

    setRefreshCookie(res, newRefreshToken);

    return ok(res, { accessToken: newAccessToken }, 'Token refreshed.');
  } catch (err) {
    next(err);
  }
}

// ─── Logout ───────────────────────────────────────────────────────────

async function logout(req, res, next) {
  try {
    const token = req.cookies?.[REFRESH_TOKEN_COOKIE];
    if (token) {
      // Revoke in DB so the token can never be reused
      await prisma.refreshToken.updateMany({
        where: { token, revoked: false },
        data: { revoked: true },
      });
    }
    clearRefreshCookie(res);
    return ok(res, {}, 'Logged out successfully.');
  } catch (err) {
    next(err);
  }
}

// ─── Me ───────────────────────────────────────────────────────────────
// Returns the currently authenticated user's profile.

async function me(req, res, next) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: { artisanProfile: true },
    });
    if (!user) return unauthorized(res, 'User not found.');
    return ok(res, { user: safeUser(user) });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login, refresh, logout, me };
