const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const prisma = require('../config/prisma');
const {
  sendVerificationEmail,
  sendWelcomeEmail,
  sendPasswordResetEmail,
} = require('../utils/mailer');
const { ok, badRequest, notFound } = require('../utils/response');

// ─── Helpers ──────────────────────────────────────────────────────────

function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}

// ─── POST /api/email/send-verification ────────────────────────────────
// (Re)sends verification email to the authenticated user.

async function sendVerification(req, res, next) {
  try {
    // Works two ways:
    // 1. Authenticated (logged in user) — uses req.user.id
    // 2. Unauthenticated (login page resend) — accepts { email } in body
    let user;
    if (req.user?.id) {
      user = await prisma.user.findUnique({ where: { id: req.user.id } });
    } else if (req.body?.email) {
      user = await prisma.user.findUnique({ where: { email: req.body.email } });
    }

    // Always return success even if user not found — prevents email enumeration
    if (!user || user.emailVerified) {
      return ok(res, {}, 'If that email exists and is unverified, a link has been sent.');
    }

    // Invalidate any existing unused tokens for this user
    await prisma.emailVerification.updateMany({
      where: { userId: user.id, usedAt: null },
      data: { usedAt: new Date() },
    });

    const token     = generateToken();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

    await prisma.emailVerification.create({
      data: { userId: user.id, token, expiresAt },
    });

    const verifyUrl = `${process.env.APP_URL || 'http://localhost:4000'}/verify-email.html?token=${token}`;

    await sendVerificationEmail({
      to: user.email,
      fullName: user.fullName,
      verifyUrl,
    });

    return ok(res, {}, 'Verification email sent. Check your inbox.');
  } catch (err) { next(err); }
}

// ─── GET /api/email/verify?token=xxx ──────────────────────────────────
// Validates the token and marks the user's email as verified.

async function verifyEmail(req, res, next) {
  try {
    const { token } = req.query;
    if (!token) return badRequest(res, 'Verification token is required.');

    const record = await prisma.emailVerification.findUnique({ where: { token } });

    if (!record) return badRequest(res, 'Invalid verification link.');
    if (record.usedAt) return badRequest(res, 'This verification link has already been used.');
    if (record.expiresAt < new Date()) return badRequest(res, 'This verification link has expired. Request a new one.');

    // Mark verified
    await Promise.all([
      prisma.user.update({
        where: { id: record.userId },
        data: { emailVerified: true },
      }),
      prisma.emailVerification.update({
        where: { token },
        data: { usedAt: new Date() },
      }),
    ]);

    const user = await prisma.user.findUnique({ where: { id: record.userId } });

    // Send welcome email now that they're verified
    await sendWelcomeEmail({ to: user.email, fullName: user.fullName, role: user.role });

    return ok(res, { email: user.email }, 'Email verified successfully. Welcome to ArtisanEye!');
  } catch (err) { next(err); }
}

// ─── POST /api/email/forgot-password ──────────────────────────────────
// Sends a password reset link. Public route — no auth needed.

async function forgotPassword(req, res, next) {
  try {
    const { email } = req.body;
    if (!email) return badRequest(res, 'Email is required.');

    const user = await prisma.user.findUnique({
      where: { email: email.toLowerCase().trim() },
    });

    // Always return success to avoid email enumeration
    if (!user) {
      return ok(res, {}, 'If an account exists with that email, a reset link has been sent.');
    }

    // Invalidate previous reset tokens
    await prisma.passwordReset.updateMany({
      where: { userId: user.id, usedAt: null },
      data: { usedAt: new Date() },
    });

    const token     = generateToken();
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await prisma.passwordReset.create({
      data: { userId: user.id, token, expiresAt },
    });

    const resetUrl = `${process.env.APP_URL || 'http://localhost:4000'}/reset-password.html?token=${token}`;

    await sendPasswordResetEmail({
      to: user.email,
      fullName: user.fullName,
      resetUrl,
    });

    return ok(res, {}, 'If an account exists with that email, a reset link has been sent.');
  } catch (err) { next(err); }
}

// ─── POST /api/email/reset-password ───────────────────────────────────
// Validates the reset token and sets the new password.

async function resetPassword(req, res, next) {
  try {
    const { token, password } = req.body;

    if (!token)    return badRequest(res, 'Reset token is required.');
    if (!password) return badRequest(res, 'New password is required.');
    if (password.length < 8) return badRequest(res, 'Password must be at least 8 characters.');
    if (!/[A-Z]/.test(password)) return badRequest(res, 'Password must contain at least one uppercase letter.');
    if (!/[0-9]/.test(password)) return badRequest(res, 'Password must contain at least one number.');

    const record = await prisma.passwordReset.findUnique({ where: { token } });

    if (!record)        return badRequest(res, 'Invalid reset link.');
    if (record.usedAt)  return badRequest(res, 'This reset link has already been used.');
    if (record.expiresAt < new Date()) return badRequest(res, 'This reset link has expired. Request a new one.');

    const passwordHash = await bcrypt.hash(password, 12);

    await Promise.all([
      // Update password
      prisma.user.update({
        where: { id: record.userId },
        data: { passwordHash },
      }),
      // Mark token used
      prisma.passwordReset.update({
        where: { token },
        data: { usedAt: new Date() },
      }),
      // Revoke ALL refresh tokens — force re-login on all devices
      prisma.refreshToken.updateMany({
        where: { userId: record.userId, revoked: false },
        data: { revoked: true },
      }),
    ]);

    return ok(res, {}, 'Password reset successfully. Please log in with your new password.');
  } catch (err) { next(err); }
}

module.exports = { sendVerification, verifyEmail, forgotPassword, resetPassword };
