const prisma = require('../config/prisma');
const { ok, notFound, forbidden } = require('../utils/response');

// ─── GET /api/notifications ────────────────────────────────────────────
// List the authenticated user's notifications, newest first.
// Query: ?page=1&limit=20&unreadOnly=true

async function listNotifications(req, res, next) {
  try {
    const userId = req.user.id;
    const { page = '1', limit = '20', unreadOnly } = req.query;

    const pageNum  = Math.max(1, parseInt(page));
    const pageSize = Math.min(50, parseInt(limit));

    const where = {
      userId,
      ...(unreadOnly === 'true' && { readAt: null }),
    };

    const [notifications, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (pageNum - 1) * pageSize,
        take: pageSize,
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId, readAt: null } }),
    ]);

    return ok(res, {
      notifications,
      unreadCount,
      pagination: { page: pageNum, limit: pageSize, total, pages: Math.ceil(total / pageSize) },
    });
  } catch (err) { next(err); }
}

// ─── PATCH /api/notifications/:id/read ─────────────────────────────────

async function markRead(req, res, next) {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const notification = await prisma.notification.findUnique({ where: { id } });
    if (!notification) return notFound(res, 'Notification not found.');
    if (notification.userId !== userId) return forbidden(res, 'Not your notification.');

    const updated = await prisma.notification.update({
      where: { id },
      data: { readAt: notification.readAt || new Date() },
    });

    return ok(res, { notification: updated });
  } catch (err) { next(err); }
}

// ─── PATCH /api/notifications/read-all ─────────────────────────────────

async function markAllRead(req, res, next) {
  try {
    const userId = req.user.id;
    const { count } = await prisma.notification.updateMany({
      where: { userId, readAt: null },
      data: { readAt: new Date() },
    });
    return ok(res, { markedRead: count }, `${count} notification(s) marked as read.`);
  } catch (err) { next(err); }
}

module.exports = { listNotifications, markRead, markAllRead };
