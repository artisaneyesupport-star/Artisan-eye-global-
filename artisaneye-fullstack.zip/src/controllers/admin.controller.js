const prisma = require('../config/prisma');
const {
  sendVerificationApprovedEmail,
  sendVerificationRejectedEmail,
} = require('../utils/mailer');
const { notifyUser } = require('../utils/notify');
const { ok, badRequest, notFound } = require('../utils/response');

// ─── GET /api/admin/verification-queue ────────────────────────────────
// List all artisans with PENDING verification status.

async function getVerificationQueue(req, res, next) {
  try {
    const { page = '1', limit = '20' } = req.query;
    const pageNum  = Math.max(1, parseInt(page));
    const pageSize = Math.min(50, parseInt(limit));

    const [profiles, total] = await Promise.all([
      prisma.artisanProfile.findMany({
        where: { verificationStatus: 'PENDING' },
        orderBy: { updatedAt: 'asc' }, // oldest first — FIFO queue
        skip: (pageNum - 1) * pageSize,
        take: pageSize,
        include: {
          user: { select: { id: true, fullName: true, email: true, phone: true, createdAt: true } },
        },
      }),
      prisma.artisanProfile.count({ where: { verificationStatus: 'PENDING' } }),
    ]);

    return ok(res, {
      profiles,
      pagination: { page: pageNum, limit: pageSize, total, pages: Math.ceil(total / pageSize) },
    });
  } catch (err) { next(err); }
}

// ─── PATCH /api/admin/verification/:profileId/approve ─────────────────

async function approveVerification(req, res, next) {
  try {
    const { profileId } = req.params;

    const profile = await prisma.artisanProfile.findUnique({
      where: { id: profileId },
      include: { user: true },
    });
    if (!profile)                                    return notFound(res, 'Artisan profile not found.');
    if (profile.verificationStatus === 'VERIFIED')   return badRequest(res, 'Profile is already verified.');

    await Promise.all([
      prisma.artisanProfile.update({
        where: { id: profileId },
        data: { verificationStatus: 'VERIFIED' },
      }),
      prisma.adminAction.create({
        data: {
          adminId:    req.user.id,
          targetType: 'artisan_profile',
          targetId:   profileId,
          action:     'verify_approve',
        },
      }),
    ]);

    // Notify artisan by email
    await sendVerificationApprovedEmail({
      to:       profile.user.email,
      fullName: profile.user.fullName,
    });
    await notifyUser({
      userId: profile.userId,
      type: 'VERIFICATION',
      title: "You're now verified",
      body: 'Your ID has been confirmed. The verified badge is now live on your profile.',
    }, req.app.get('io'));

    return ok(res, {}, `${profile.user.fullName}'s profile has been verified.`);
  } catch (err) { next(err); }
}

// ─── PATCH /api/admin/verification/:profileId/reject ──────────────────

async function rejectVerification(req, res, next) {
  try {
    const { profileId } = req.params;
    const { reason }    = req.body;

    const profile = await prisma.artisanProfile.findUnique({
      where: { id: profileId },
      include: { user: true },
    });
    if (!profile) return notFound(res, 'Artisan profile not found.');

    await Promise.all([
      prisma.artisanProfile.update({
        where: { id: profileId },
        data: { verificationStatus: 'REJECTED' },
      }),
      prisma.adminAction.create({
        data: {
          adminId:    req.user.id,
          targetType: 'artisan_profile',
          targetId:   profileId,
          action:     'verify_reject',
          reason:     reason || null,
        },
      }),
    ]);

    await sendVerificationRejectedEmail({
      to:       profile.user.email,
      fullName: profile.user.fullName,
      reason:   reason || null,
    });
    await notifyUser({
      userId: profile.userId,
      type: 'VERIFICATION',
      title: 'Verification not approved',
      body: reason || 'Your verification documents could not be approved. Please review and resubmit.',
    }, req.app.get('io'));

    return ok(res, {}, `Verification rejected for ${profile.user.fullName}.`);
  } catch (err) { next(err); }
}

// ─── GET /api/admin/users ─────────────────────────────────────────────

async function listUsers(req, res, next) {
  try {
    const { role, search, page = '1', limit = '20' } = req.query;
    const pageNum  = Math.max(1, parseInt(page));
    const pageSize = Math.min(100, parseInt(limit));

    const where = {
      ...(role   && { role }),
      ...(search && {
        OR: [
          { fullName: { contains: search, mode: 'insensitive' } },
          { email:    { contains: search, mode: 'insensitive' } },
        ],
      }),
    };

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (pageNum - 1) * pageSize,
        take: pageSize,
        select: {
          id: true, fullName: true, email: true, role: true,
          emailVerified: true, createdAt: true,
          artisanProfile: {
            select: { verificationStatus: true, plan: true, rating: true, jobsCompleted: true },
          },
        },
      }),
      prisma.user.count({ where }),
    ]);

    return ok(res, {
      users,
      pagination: { page: pageNum, limit: pageSize, total, pages: Math.ceil(total / pageSize) },
    });
  } catch (err) { next(err); }
}

// ─── GET /api/admin/stats ─────────────────────────────────────────────
// Platform-level overview numbers.

async function getStats(req, res, next) {
  try {
    const [
      totalUsers, totalArtisans, totalClients,
      verifiedArtisans, pendingVerification,
      totalJobs, activeJobs, completedJobs,
      totalRevenue,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { role: 'ARTISAN' } }),
      prisma.user.count({ where: { role: 'CLIENT' } }),
      prisma.artisanProfile.count({ where: { verificationStatus: 'VERIFIED' } }),
      prisma.artisanProfile.count({ where: { verificationStatus: 'PENDING' } }),
      prisma.job.count(),
      prisma.job.count({ where: { status: { in: ['ACCEPTED', 'IN_PROGRESS'] } } }),
      prisma.job.count({ where: { status: 'CONFIRMED' } }),
      prisma.paymentEvent.aggregate({ where: { status: 'success' }, _sum: { amount: true } }),
    ]);

    return ok(res, {
      users:    { total: totalUsers, artisans: totalArtisans, clients: totalClients },
      verification: { verified: verifiedArtisans, pending: pendingVerification },
      jobs:     { total: totalJobs, active: activeJobs, completed: completedJobs },
      revenue:  { totalKobo: totalRevenue._sum.amount || 0, totalNaira: (totalRevenue._sum.amount || 0) / 100 },
    });
  } catch (err) { next(err); }
}

// ─── PATCH /api/admin/jobs/:id/resolve-dispute ────────────────────────

async function resolveDispute(req, res, next) {
  try {
    const { id }      = req.params;
    const { resolution, outcome } = req.body;

    if (!resolution || !outcome) {
      return badRequest(res, 'resolution (note) and outcome (CONFIRMED or CANCELLED) are required.');
    }
    if (!['CONFIRMED', 'CANCELLED'].includes(outcome)) {
      return badRequest(res, 'outcome must be CONFIRMED or CANCELLED.');
    }

    const job = await prisma.job.findUnique({ where: { id } });
    if (!job)                      return notFound(res, 'Job not found.');
    if (job.status !== 'DISPUTED') return badRequest(res, 'Job is not in DISPUTED status.');

    await Promise.all([
      prisma.job.update({ where: { id }, data: { status: outcome } }),
      prisma.adminAction.create({
        data: {
          adminId:    req.user.id,
          targetType: 'job',
          targetId:   id,
          action:     `dispute_resolved_${outcome.toLowerCase()}`,
          reason:     resolution,
        },
      }),
    ]);

    const io = req.app.get('io');
    const disputeMsg = `Admin resolved the dispute on "${job.title}": ${resolution}`;
    await Promise.all([
      notifyUser({ userId: job.clientId, type: 'JOB_UPDATE', title: 'Dispute resolved', body: disputeMsg, link: job.id }, io),
      notifyUser({ userId: job.artisanUserId, type: 'JOB_UPDATE', title: 'Dispute resolved', body: disputeMsg, link: job.id }, io),
    ]);

    return ok(res, {}, `Dispute resolved — job marked as ${outcome}.`);
  } catch (err) { next(err); }
}

module.exports = {
  getVerificationQueue,
  approveVerification,
  rejectVerification,
  listUsers,
  getStats,
  resolveDispute,
};
