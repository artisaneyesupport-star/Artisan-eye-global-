const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const prisma = require('../config/prisma');
const {
  initializeTransaction,
  verifyTransaction,
  createCustomer,
  cancelSubscription,
  verifyWebhookSignature,
  PLAN_CODES,
  PLAN_AMOUNTS,
} = require('../utils/paystack');
const {
  sendPaymentConfirmationEmail,
  sendSubscriptionCancelledEmail,
} = require('../utils/mailer');
const { ok, badRequest, notFound, serverError } = require('../utils/response');

// ─── Helpers ──────────────────────────────────────────────────────────

/**
 * Upgrades or downgrades an artisan's plan in DB.
 * Uses a transaction — both updates succeed or both fail atomically.
 */
async function applyPlan(userId, plan, paystackData = {}) {
  const now = new Date();
  const periodEnd = new Date(now);
  periodEnd.setMonth(periodEnd.getMonth() + 1);

  await prisma.$transaction([
    // Update the artisan profile plan
    prisma.artisanProfile.updateMany({
      where: { userId },
      data: { plan },
    }),
    // Upsert the subscription record
    prisma.subscription.upsert({
      where: { userId },
      create: {
        userId,
        plan,
        status: 'ACTIVE',
        paystackCustomerCode: paystackData.customer?.customer_code || null,
        paystackSubCode: paystackData.subscription_code || null,
        currentPeriodStart: now,
        currentPeriodEnd: periodEnd,
      },
      update: {
        plan,
        status: 'ACTIVE',
        paystackCustomerCode: paystackData.customer?.customer_code || null,
        paystackSubCode: paystackData.subscription_code || null,
        currentPeriodStart: now,
        currentPeriodEnd: periodEnd,
        cancelledAt: null,
      },
    }),
  ]);
}

// ─── POST /api/payments/initialize ────────────────────────────────────
/**
 * Creates a Paystack checkout URL for the requested plan.
 * ARTISAN only.
 * Body: { plan: "PRO" | "TEAM" }
 */
async function initializePayment(req, res, next) {
  try {
    const { plan } = req.body;

    if (!plan || !['PRO', 'TEAM'].includes(plan.toUpperCase())) {
      return badRequest(res, 'plan must be "PRO" or "TEAM".');
    }

    const planKey = plan.toUpperCase();

    // Artisan must have a profile
    const profile = await prisma.artisanProfile.findUnique({
      where: { userId: req.user.id },
    });
    if (!profile) return notFound(res, 'Artisan profile not found.');

    // Check not already on this plan
    if (profile.plan === planKey) {
      return badRequest(res, `You are already on the ${planKey} plan.`);
    }

    const user = await prisma.user.findUnique({ where: { id: req.user.id } });

    const reference = `AE-${planKey}-${uuidv4().split('-')[0].toUpperCase()}`;
    const planCode  = PLAN_CODES[planKey]();

    if (!planCode) {
      return serverError(res, `Paystack plan code for ${planKey} is not configured. Check PAYSTACK_PLAN_${planKey} in .env.`);
    }

    const paystackRes = await initializeTransaction({
      email: user.email,
      amountKobo: PLAN_AMOUNTS[planKey],
      reference,
      plan: planCode,
      metadata: {
        userId: user.id,
        planKey,
        fullName: user.fullName,
      },
    });

    if (!paystackRes.status) {
      return serverError(res, `Paystack error: ${paystackRes.message}`);
    }

    return ok(res, {
      authorizationUrl: paystackRes.data.authorization_url,
      reference: paystackRes.data.reference,
      plan: planKey,
      amountNaira: PLAN_AMOUNTS[planKey] / 100,
    }, 'Payment initialized. Redirect user to authorizationUrl.');
  } catch (err) { next(err); }
}

// ─── GET /api/payments/verify/:reference ──────────────────────────────
/**
 * Called after Paystack redirects back to callback_url.
 * Verifies the payment and upgrades the plan if successful.
 */
async function verifyPayment(req, res, next) {
  try {
    const { reference } = req.params;

    // Check we haven't processed this reference already
    const existing = await prisma.paymentEvent.findUnique({ where: { reference } });
    if (existing) {
      return ok(res, { alreadyProcessed: true, status: existing.status }, 'Payment already verified.');
    }

    const paystackRes = await verifyTransaction(reference);

    if (!paystackRes.status || paystackRes.data.status !== 'success') {
      await prisma.paymentEvent.create({
        data: {
          reference,
          event: 'charge.verify',
          amount: paystackRes.data?.amount || 0,
          status: 'failed',
          paystackData: paystackRes,
        },
      });
      return badRequest(res, `Payment not successful: ${paystackRes.data?.gateway_response || 'Unknown error'}`);
    }

    const meta = paystackRes.data.metadata || {};
    const userId = meta.userId || req.user.id;
    const planKey = meta.planKey;

    // Record the payment event
    await prisma.paymentEvent.create({
      data: {
        userId,
        reference,
        event: 'charge.success',
        amount: paystackRes.data.amount,
        currency: paystackRes.data.currency,
        status: 'success',
        paystackData: paystackRes.data,
      },
    });

    // Apply the plan upgrade
    if (planKey && ['PRO', 'TEAM'].includes(planKey)) {
      await applyPlan(userId, planKey, paystackRes.data);
    }

    // Send confirmation email (non-blocking)
    try {
      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (user) {
        const sub = await prisma.subscription.findUnique({ where: { userId } });
        const nextBillingDate = sub?.currentPeriodEnd
          ? new Date(sub.currentPeriodEnd).toLocaleDateString('en-NG', { day: 'numeric', month: 'long', year: 'numeric' })
          : 'Next month';
        await sendPaymentConfirmationEmail({
          to: user.email,
          fullName: user.fullName,
          plan: planKey,
          amountNaira: paystackRes.data.amount / 100,
          reference,
          nextBillingDate,
        });
      }
    } catch (emailErr) {
      console.warn('[payments] Could not send confirmation email:', emailErr.message);
    }

    return ok(res, {
      plan: planKey,
      reference,
      amountPaid: paystackRes.data.amount / 100,
      currency: paystackRes.data.currency,
    }, `Payment verified. Your plan has been upgraded to ${planKey}.`);
  } catch (err) { next(err); }
}

// ─── POST /api/payments/webhook ───────────────────────────────────────
/**
 * Receives raw webhook events from Paystack.
 * Must be a raw body route (not JSON-parsed) — handled in app.js.
 * Paystack signs each request; we verify before processing.
 */
async function handleWebhook(req, res, next) {
  try {
    // Always return 200 immediately so Paystack doesn't retry
    res.status(200).send('OK');

    const signature = req.headers['x-paystack-signature'];
    const rawBody   = req.rawBody;

    if (!verifyWebhookSignature(rawBody, signature)) {
      console.warn('[webhook] Invalid Paystack signature — ignored.');
      return;
    }

    const event = req.body;
    const { event: eventType, data } = event;

    console.log(`[webhook] received: ${eventType}`);

    switch (eventType) {

      // ── Subscription payment succeeded ──────────────────────────────
      case 'charge.success': {
        const reference = data.reference;
        const existing  = await prisma.paymentEvent.findUnique({ where: { reference } });
        if (existing) break; // already handled by verify endpoint

        const meta    = data.metadata || {};
        const userId  = meta.userId;
        const planKey = meta.planKey;

        await prisma.paymentEvent.create({
          data: {
            userId,
            reference,
            event: eventType,
            amount: data.amount,
            currency: data.currency,
            status: 'success',
            paystackData: data,
          },
        });

        if (userId && planKey && ['PRO', 'TEAM'].includes(planKey)) {
          await applyPlan(userId, planKey, data);
          console.log(`[webhook] plan upgraded: user=${userId} plan=${planKey}`);
        }
        break;
      }

      // ── Subscription renewed ─────────────────────────────────────────
      case 'subscription.create':
      case 'invoice.payment_failed': {
        // Locate subscription by Paystack subscription code
        const subCode = data.subscription_code;
        if (!subCode) break;

        const sub = await prisma.subscription.findFirst({
          where: { paystackSubCode: subCode },
        });
        if (!sub) break;

        if (eventType === 'subscription.create') {
          const periodEnd = new Date(data.next_payment_date || Date.now());
          await prisma.subscription.update({
            where: { id: sub.id },
            data: { status: 'ACTIVE', currentPeriodEnd: periodEnd },
          });
        } else {
          // Payment failed — mark past_due
          await prisma.subscription.update({
            where: { id: sub.id },
            data: { status: 'PAST_DUE' },
          });
        }
        break;
      }

      // ── Subscription cancelled ───────────────────────────────────────
      case 'subscription.disable': {
        const subCode = data.subscription_code;
        const sub = await prisma.subscription.findFirst({
          where: { paystackSubCode: subCode },
        });
        if (!sub) break;

        await Promise.all([
          prisma.subscription.update({
            where: { id: sub.id },
            data: { status: 'CANCELLED', cancelledAt: new Date() },
          }),
          // Downgrade artisan back to STARTER
          prisma.artisanProfile.updateMany({
            where: { userId: sub.userId },
            data: { plan: 'STARTER' },
          }),
        ]);
        console.log(`[webhook] subscription cancelled + plan downgraded: user=${sub.userId}`);
        break;
      }

      default:
        console.log(`[webhook] unhandled event type: ${eventType}`);
    }
  } catch (err) {
    console.error('[webhook] error:', err.message);
  }
}

// ─── GET /api/payments/subscription ──────────────────────────────────
// Returns the current user's subscription status and plan.

async function getSubscription(req, res, next) {
  try {
    const [subscription, profile] = await Promise.all([
      prisma.subscription.findUnique({ where: { userId: req.user.id } }),
      prisma.artisanProfile.findUnique({ where: { userId: req.user.id } }),
    ]);

    return ok(res, {
      currentPlan: profile?.plan || 'STARTER',
      subscription: subscription || null,
    });
  } catch (err) { next(err); }
}

// ─── POST /api/payments/cancel ────────────────────────────────────────
// Cancel the active subscription.

async function cancelPlan(req, res, next) {
  try {
    const subscription = await prisma.subscription.findUnique({
      where: { userId: req.user.id },
    });

    if (!subscription || subscription.status !== 'ACTIVE') {
      return badRequest(res, 'No active subscription to cancel.');
    }

    // If we have a Paystack subscription code, tell Paystack to stop billing
    if (subscription.paystackSubCode) {
      const { emailToken } = req.body; // Paystack requires email token for cancellation
      if (!emailToken) {
        return badRequest(res, 'emailToken is required. Paystack sends this to the customer\'s email when they request cancellation.');
      }
      await cancelSubscription(subscription.paystackSubCode, emailToken);
    }

    // Mark cancelled locally (webhook will confirm and downgrade plan)
    await prisma.subscription.update({
      where: { userId: req.user.id },
      data: { status: 'CANCELLED', cancelledAt: new Date() },
    });

    // Send cancellation email (non-blocking)
    try {
      const user = await prisma.user.findUnique({ where: { id: req.user.id } });
      const activeUntil = subscription.currentPeriodEnd
        ? new Date(subscription.currentPeriodEnd).toLocaleDateString('en-NG', {
            day: 'numeric', month: 'long', year: 'numeric',
          })
        : 'end of current billing period';
      if (user) {
        await sendSubscriptionCancelledEmail({
          to: user.email,
          fullName: user.fullName,
          plan: subscription.plan,
          activeUntil,
        });
      }
    } catch (emailErr) {
      console.warn('[payments] Could not send cancellation email:', emailErr.message);
    }

    return ok(res, {}, 'Subscription cancelled. Your plan stays active until the current billing period ends.');
  } catch (err) { next(err); }
}

module.exports = { initializePayment, verifyPayment, handleWebhook, getSubscription, cancelPlan };
