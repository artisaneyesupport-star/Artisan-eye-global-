const prisma   = require('../config/prisma');
const { sendNewMessageEmail } = require('../utils/mailer');
const { recalcRating } = require('../utils/ratings');
const { notifyUser } = require('../utils/notify');
const { ok, created, badRequest, forbidden, notFound } = require('../utils/response');

// ─── Helpers ──────────────────────────────────────────────────────────

const VALID_TRANSITIONS = {
  PENDING:     { ARTISAN: ['ACCEPTED', 'CANCELLED'], CLIENT: ['CANCELLED'] },
  ACCEPTED:    { ARTISAN: ['IN_PROGRESS', 'CANCELLED'], CLIENT: ['CANCELLED'] },
  IN_PROGRESS: { ARTISAN: ['COMPLETED'], CLIENT: ['DISPUTED'] },
  COMPLETED:   { CLIENT: ['CONFIRMED', 'DISPUTED'], ARTISAN: [] },
  CONFIRMED:   { CLIENT: [], ARTISAN: [] },   // terminal
  CANCELLED:   { CLIENT: [], ARTISAN: [] },   // terminal
  DISPUTED:    { CLIENT: [], ARTISAN: [] },   // terminal — handled by admin
};

function canTransition(currentStatus, newStatus, role) {
  return VALID_TRANSITIONS[currentStatus]?.[role]?.includes(newStatus) ?? false;
}

async function notifyJobUpdate(job, recipientId, message, io, title = 'Job update') {
  try {
    const recipient = await prisma.user.findUnique({ where: { id: recipientId } });
    if (recipient) {
      const jobUrl = `${process.env.APP_URL || 'http://localhost:4000'}/dashboard.html#job-${job.id}`;
      await sendNewMessageEmail({
        to: recipient.email,
        recipientName: recipient.fullName,
        senderName: 'ArtisanEye',
        messagePreview: message,
        threadUrl: jobUrl,
      });
    }
  } catch (err) {
    console.warn('[jobs] email notification failed:', err.message);
  }

  // In-app notification — independent of email; a failed email shouldn't
  // block this from showing in the Notifications screen.
  await notifyUser({ userId: recipientId, type: 'JOB_UPDATE', title, body: message, link: job.id }, io);
}

// ─── POST /api/jobs ───────────────────────────────────────────────────
// CLIENT creates a job request for an artisan.

async function createJob(req, res, next) {
  try {
    const clientId = req.user.id;
    const { artisanUserId, title, description, agreedPrice, scheduledAt } = req.body;

    if (!artisanUserId || !title || !description) {
      return badRequest(res, 'artisanUserId, title, and description are required.');
    }

    const artisan = await prisma.user.findUnique({ where: { id: artisanUserId } });
    if (!artisan || artisan.role !== 'ARTISAN') {
      return notFound(res, 'Artisan not found.');
    }
    if (artisanUserId === clientId) {
      return badRequest(res, 'You cannot request a job from yourself.');
    }

    const job = await prisma.job.create({
      data: {
        clientId,
        artisanUserId,
        title,
        description,
        agreedPrice: agreedPrice || null,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
      },
      include: {
        client:  { select: { id: true, fullName: true, email: true } },
        artisan: { select: { id: true, fullName: true, email: true } },
      },
    });

    // Notify artisan
    await notifyJobUpdate(
      job,
      artisanUserId,
      `${job.client.fullName} has sent you a job request: "${title}".`,
      req.app.get('io'),
      'New job request'
    );

    return created(res, { job }, 'Job request sent.');
  } catch (err) { next(err); }
}

// ─── GET /api/jobs ────────────────────────────────────────────────────
// List jobs for the authenticated user (as client or artisan).

async function listJobs(req, res, next) {
  try {
    const userId = req.user.id;
    const role   = req.user.role;
    const { status, page = '1', limit = '20' } = req.query;

    const pageNum  = Math.max(1, parseInt(page));
    const pageSize = Math.min(50, parseInt(limit));

    const where = {
      ...(role === 'CLIENT'  && { clientId: userId }),
      ...(role === 'ARTISAN' && { artisanUserId: userId }),
      ...(status             && { status }),
    };

    const [jobs, total] = await Promise.all([
      prisma.job.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (pageNum - 1) * pageSize,
        take: pageSize,
        include: {
          client:  { select: { id: true, fullName: true, avatarUrl: true } },
          artisan: { select: { id: true, fullName: true, avatarUrl: true } },
          review:  true,
        },
      }),
      prisma.job.count({ where }),
    ]);

    return ok(res, {
      jobs,
      pagination: { page: pageNum, limit: pageSize, total, pages: Math.ceil(total / pageSize) },
    });
  } catch (err) { next(err); }
}

// ─── GET /api/jobs/:id ────────────────────────────────────────────────

async function getJob(req, res, next) {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const job = await prisma.job.findUnique({
      where: { id },
      include: {
        client:  { select: { id: true, fullName: true, avatarUrl: true, email: true } },
        artisan: { select: { id: true, fullName: true, avatarUrl: true, email: true } },
        review:  true,
      },
    });

    if (!job) return notFound(res, 'Job not found.');
    if (job.clientId !== userId && job.artisanUserId !== userId && req.user.role !== 'ADMIN') {
      return forbidden(res, 'You are not a participant in this job.');
    }

    return ok(res, { job });
  } catch (err) { next(err); }
}

// ─── PATCH /api/jobs/:id/status ───────────────────────────────────────
// State-machine transition. Enforces valid transitions per role.

async function updateJobStatus(req, res, next) {
  try {
    const { id }     = req.params;
    const { status, cancelReason } = req.body;
    const userId     = req.user.id;
    const role       = req.user.role;

    if (!status) return badRequest(res, 'status is required.');

    const job = await prisma.job.findUnique({ where: { id } });
    if (!job) return notFound(res, 'Job not found.');

    if (job.clientId !== userId && job.artisanUserId !== userId) {
      return forbidden(res, 'You are not a participant in this job.');
    }

    if (!canTransition(job.status, status, role)) {
      return badRequest(res, `Cannot transition from ${job.status} to ${status} as ${role}.`);
    }

    const now = new Date();
    const updateData = {
      status,
      ...(status === 'IN_PROGRESS' && { startedAt: now }),
      ...(status === 'COMPLETED'   && { completedAt: now }),
      ...(status === 'CONFIRMED'   && { confirmedAt: now }),
      ...(status === 'CANCELLED'   && { cancelledAt: now, cancelledBy: userId, cancelReason: cancelReason || null }),
    };

    const updated = await prisma.job.update({
      where: { id },
      data: updateData,
      include: {
        client:  { select: { id: true, fullName: true } },
        artisan: { select: { id: true, fullName: true } },
      },
    });

    // Notify the other party
    const recipientId = userId === job.clientId ? job.artisanUserId : job.clientId;
    const messages = {
      ACCEPTED:    `${updated.artisan.fullName} accepted your job request: "${job.title}".`,
      IN_PROGRESS: `${updated.artisan.fullName} has started work on: "${job.title}".`,
      COMPLETED:   `${updated.artisan.fullName} has marked "${job.title}" as complete. Please confirm to leave a review.`,
      CONFIRMED:   `${updated.client.fullName} confirmed the job "${job.title}" as complete.`,
      CANCELLED:   `The job "${job.title}" was cancelled.`,
      DISPUTED:    `A dispute has been raised on "${job.title}". Our team will review it.`,
    };
    const titles = {
      ACCEPTED: 'Job request accepted',
      IN_PROGRESS: 'Job started',
      COMPLETED: 'Job marked complete',
      CONFIRMED: 'Job confirmed',
      CANCELLED: 'Job cancelled',
      DISPUTED: 'Dispute raised',
    };

    if (messages[status]) {
      await notifyJobUpdate(updated, recipientId, messages[status], req.app.get('io'), titles[status]);
    }

    return ok(res, { job: updated }, `Job status updated to ${status}.`);
  } catch (err) { next(err); }
}

// ─── POST /api/jobs/:id/review ────────────────────────────────────────
// CLIENT leaves a review — only allowed after job is CONFIRMED.

async function leaveReview(req, res, next) {
  try {
    const { id }      = req.params;
    const { rating, comment } = req.body;
    const reviewerId  = req.user.id;

    if (!rating || rating < 1 || rating > 5) {
      return badRequest(res, 'rating must be 1–5.');
    }

    const job = await prisma.job.findUnique({
      where: { id },
      include: { review: true },
    });

    if (!job)                          return notFound(res, 'Job not found.');
    if (job.clientId !== reviewerId)   return forbidden(res, 'Only the client can leave a review.');
    if (job.status !== 'CONFIRMED')    return badRequest(res, 'You can only review a confirmed job.');
    if (job.review)                    return badRequest(res, 'A review has already been submitted for this job.');

    const artisanProfile = await prisma.artisanProfile.findUnique({
      where: { userId: job.artisanUserId },
    });
    if (!artisanProfile) return notFound(res, 'Artisan profile not found.');

    const reviewer = await prisma.user.findUnique({ where: { id: reviewerId } });

    const review = await prisma.review.create({
      data: {
        jobId:           id,
        artisanProfileId: artisanProfile.id,
        reviewerId,
        reviewerName:    reviewer.fullName,
        rating:          parseInt(rating),
        comment:         comment || null,
      },
    });

    await recalcRating(artisanProfile.id);

    return created(res, { review }, 'Review submitted.');
  } catch (err) { next(err); }
}

module.exports = { createJob, listJobs, getJob, updateJobStatus, leaveReview };
