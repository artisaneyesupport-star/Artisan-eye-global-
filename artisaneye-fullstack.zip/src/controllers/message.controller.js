const prisma = require('../config/prisma');
const { ok, created, badRequest, forbidden, notFound } = require('../utils/response');
const { sendNewMessageEmail } = require('../utils/mailer');
const { notifyUser } = require('../utils/notify');

// ─── Helpers ──────────────────────────────────────────────────────────

/**
 * Build a thread summary object safe to return in list views —
 * includes the last message and unread count for the requesting user.
 */
function threadSummary(thread, myUserId) {
  const lastMsg = thread.messages?.[0] || null;
  const unread = thread.messages?.filter(
    (m) => m.senderId !== myUserId && !m.readAt
  ).length ?? 0;

  return {
    id: thread.id,
    createdAt: thread.createdAt,
    updatedAt: thread.updatedAt,
    client: thread.client,
    artisan: thread.artisan,
    lastMessage: lastMsg
      ? { body: lastMsg.body, senderId: lastMsg.senderId, createdAt: lastMsg.createdAt }
      : null,
    unreadCount: unread,
  };
}

// ─── POST /api/messages/threads ───────────────────────────────────────
// Start (or retrieve existing) conversation with an artisan.
// Called by CLIENT; body: { artisanUserId }

async function startThread(req, res, next) {
  try {
    const clientId  = req.user.id;
    const { artisanUserId } = req.body;

    if (!artisanUserId) return badRequest(res, 'artisanUserId is required.');
    if (artisanUserId === clientId) return badRequest(res, 'You cannot message yourself.');

    // Verify the target is actually an artisan
    const artisan = await prisma.user.findUnique({ where: { id: artisanUserId } });
    if (!artisan || artisan.role !== 'ARTISAN') {
      return notFound(res, 'Artisan not found.');
    }

    // Upsert — return existing thread if one already exists
    let thread = await prisma.thread.findUnique({
      where: { clientId_artisanId: { clientId, artisanId: artisanUserId } },
      include: {
        client:  { select: { id: true, fullName: true, avatarUrl: true } },
        artisan: { select: { id: true, fullName: true, avatarUrl: true } },
        messages: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    });

    if (!thread) {
      thread = await prisma.thread.create({
        data: { clientId, artisanId: artisanUserId },
        include: {
          client:  { select: { id: true, fullName: true, avatarUrl: true } },
          artisan: { select: { id: true, fullName: true, avatarUrl: true } },
          messages: { orderBy: { createdAt: 'desc' }, take: 1 },
        },
      });
      return created(res, { thread: threadSummary(thread, clientId) }, 'Thread created.');
    }

    return ok(res, { thread: threadSummary(thread, clientId) }, 'Thread already exists.');
  } catch (err) { next(err); }
}

// ─── GET /api/messages/threads ────────────────────────────────────────
// List all threads for the authenticated user (either role).

async function listThreads(req, res, next) {
  try {
    const userId = req.user.id;
    const role   = req.user.role;

    const where =
      role === 'CLIENT'  ? { clientId:  userId } :
      role === 'ARTISAN' ? { artisanId: userId } :
      { OR: [{ clientId: userId }, { artisanId: userId }] };

    const threads = await prisma.thread.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      include: {
        client:  { select: { id: true, fullName: true, avatarUrl: true } },
        artisan: { select: { id: true, fullName: true, avatarUrl: true } },
        messages: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
    });

    // Count total unread across all threads
    const allUnread = await prisma.message.count({
      where: {
        thread: where,
        senderId: { not: userId },
        readAt: null,
      },
    });

    return ok(res, {
      threads: threads.map((t) => threadSummary(t, userId)),
      totalUnread: allUnread,
    });
  } catch (err) { next(err); }
}

// ─── GET /api/messages/threads/:threadId ──────────────────────────────
// Full thread with paginated messages.

async function getThread(req, res, next) {
  try {
    const { threadId } = req.params;
    const userId = req.user.id;
    const { page = '1', limit = '30' } = req.query;

    const pageNum  = Math.max(1, parseInt(page));
    const pageSize = Math.min(100, parseInt(limit));

    const thread = await prisma.thread.findUnique({
      where: { id: threadId },
      include: {
        client:  { select: { id: true, fullName: true, avatarUrl: true } },
        artisan: { select: { id: true, fullName: true, avatarUrl: true } },
      },
    });

    if (!thread) return notFound(res, 'Thread not found.');

    // Access guard — only the two participants can read the thread
    if (thread.clientId !== userId && thread.artisanId !== userId) {
      return forbidden(res, 'You are not a participant in this thread.');
    }

    const [messages, total] = await Promise.all([
      prisma.message.findMany({
        where: { threadId },
        orderBy: { createdAt: 'desc' },   // newest first, client reverses for display
        skip: (pageNum - 1) * pageSize,
        take: pageSize,
        include: {
          sender: { select: { id: true, fullName: true, avatarUrl: true } },
        },
      }),
      prisma.message.count({ where: { threadId } }),
    ]);

    return ok(res, {
      thread,
      messages: messages.reverse(), // chronological order for display
      pagination: { page: pageNum, limit: pageSize, total, pages: Math.ceil(total / pageSize) },
    });
  } catch (err) { next(err); }
}

// ─── POST /api/messages/threads/:threadId ─────────────────────────────
// Send a message in a thread. Body: { body }
// Also emits a Socket.io event for real-time delivery.

async function sendMessage(req, res, next) {
  try {
    const { threadId } = req.params;
    const senderId = req.user.id;
    const { body } = req.body;

    if (!body || !body.trim()) return badRequest(res, 'Message body cannot be empty.');
    if (body.length > 4000) return badRequest(res, 'Message exceeds 4000 character limit.');

    const thread = await prisma.thread.findUnique({ where: { id: threadId } });
    if (!thread) return notFound(res, 'Thread not found.');

    if (thread.clientId !== senderId && thread.artisanId !== senderId) {
      return forbidden(res, 'You are not a participant in this thread.');
    }

    const [message] = await Promise.all([
      prisma.message.create({
        data: { threadId, senderId, body: body.trim() },
        include: { sender: { select: { id: true, fullName: true, avatarUrl: true } } },
      }),
      // Bump thread.updatedAt so inbox sorts correctly
      prisma.thread.update({
        where: { id: threadId },
        data: { updatedAt: new Date() },
      }),
    ]);

    // Emit via Socket.io so the recipient gets it instantly (no polling needed)
    // req.app.get('io') is set in index.js
    const io = req.app.get('io');
    if (io) {
      io.to(`thread:${threadId}`).emit('message:new', message);
    }

    // In-app notification for the recipient — independent of email/online
    // status, so it always shows up in their Notifications screen.
    const recipientId = thread.clientId === senderId ? thread.artisanId : thread.clientId;
    await notifyUser({
      userId: recipientId,
      type: 'MESSAGE',
      title: `New message from ${message.sender.fullName}`,
      body: body.trim().substring(0, 140),
      link: threadId,
    }, io);

    // Send email notification if recipient is not currently online (non-blocking)
    try {
      const roomSockets = io ? await io.in(`thread:${threadId}`).fetchSockets() : [];
      const recipientOnline = roomSockets.some(s => s.user?.id === recipientId);

      if (!recipientOnline) {
        const recipient = await prisma.user.findUnique({ where: { id: recipientId } });
        const sender    = await prisma.user.findUnique({ where: { id: senderId } });
        if (recipient && sender) {
          const threadUrl = `${process.env.APP_URL || 'http://localhost:4000'}/dashboard.html#thread-${threadId}`;
          await sendNewMessageEmail({
            to: recipient.email,
            recipientName: recipient.fullName,
            senderName: sender.fullName,
            messagePreview: body.trim().substring(0, 120),
            threadUrl,
          });
        }
      }
    } catch (emailErr) {
      console.warn('[messages] Could not send notification email:', emailErr.message);
    }

    return created(res, { message }, 'Message sent.');
  } catch (err) { next(err); }
}

// ─── PATCH /api/messages/threads/:threadId/read ───────────────────────
// Mark all unread messages in a thread as read (for the calling user).

async function markRead(req, res, next) {
  try {
    const { threadId } = req.params;
    const userId = req.user.id;

    const thread = await prisma.thread.findUnique({ where: { id: threadId } });
    if (!thread) return notFound(res, 'Thread not found.');
    if (thread.clientId !== userId && thread.artisanId !== userId) {
      return forbidden(res, 'You are not a participant in this thread.');
    }

    const { count } = await prisma.message.updateMany({
      where: { threadId, senderId: { not: userId }, readAt: null },
      data: { readAt: new Date() },
    });

    // Notify the sender their messages were read
    const io = req.app.get('io');
    if (io && count > 0) {
      io.to(`thread:${threadId}`).emit('messages:read', { threadId, readBy: userId });
    }

    return ok(res, { markedRead: count }, `${count} message(s) marked as read.`);
  } catch (err) { next(err); }
}

// ─── DELETE /api/messages/threads/:threadId/messages/:messageId ───────
// Soft-delete (redact) own message within 10 minutes of sending.

async function deleteMessage(req, res, next) {
  try {
    const { threadId, messageId } = req.params;
    const userId = req.user.id;

    const message = await prisma.message.findUnique({ where: { id: messageId } });
    if (!message || message.threadId !== threadId) return notFound(res, 'Message not found.');
    if (message.senderId !== userId) return forbidden(res, 'You can only delete your own messages.');

    const ageMs = Date.now() - new Date(message.createdAt).getTime();
    if (ageMs > 10 * 60 * 1000) {
      return forbidden(res, 'Messages can only be deleted within 10 minutes of sending.');
    }

    const updated = await prisma.message.update({
      where: { id: messageId },
      data: { body: '[Message deleted]' },
    });

    const io = req.app.get('io');
    if (io) {
      io.to(`thread:${threadId}`).emit('message:deleted', { messageId, threadId });
    }

    return ok(res, { message: updated }, 'Message deleted.');
  } catch (err) { next(err); }
}

module.exports = { startThread, listThreads, getThread, sendMessage, markRead, deleteMessage };
