const express = require('express');
const { body } = require('express-validator');

const {
  initializePayment,
  verifyPayment,
  handleWebhook,
  getSubscription,
  cancelPlan,
} = require('../controllers/payment.controller');

const { authenticate, requireRole } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

const router = express.Router();

// ─── Validation ────────────────────────────────────────────────────────

const initRules = [
  body('plan')
    .notEmpty().withMessage('plan is required.')
    .isIn(['PRO', 'TEAM', 'pro', 'team']).withMessage('plan must be PRO or TEAM.'),
];

// ─── Routes ────────────────────────────────────────────────────────────

/**
 * POST /api/payments/webhook
 * Paystack sends events here. Must be BEFORE any JSON body-parser runs
 * so we can capture the raw body for signature verification.
 * The rawBody is attached in app.js via a verify callback.
 */
router.post(
  '/webhook',
  express.raw({ type: 'application/json' }), // capture raw bytes
  (req, res, next) => {
    // Parse body for the controller but keep rawBody for sig verification
    try {
      req.rawBody = req.body.toString('utf8');
      req.body = JSON.parse(req.rawBody);
    } catch {
      req.rawBody = '';
    }
    next();
  },
  handleWebhook,
);

/**
 * POST /api/payments/initialize
 * ARTISAN only — start a Paystack checkout for Pro or Team plan.
 * Body: { plan: "PRO" | "TEAM" }
 */
router.post(
  '/initialize',
  authenticate,
  requireRole('ARTISAN'),
  initRules,
  validate,
  initializePayment,
);

/**
 * GET /api/payments/verify/:reference
 * Called after Paystack redirects back to your callback URL.
 * Protected — only the artisan who initiated the payment should call this.
 */
router.get(
  '/verify/:reference',
  authenticate,
  requireRole('ARTISAN'),
  verifyPayment,
);

/**
 * GET /api/payments/subscription
 * Returns current plan + subscription status.
 * Works for ARTISANs — clients have no subscription.
 */
router.get(
  '/subscription',
  authenticate,
  requireRole('ARTISAN'),
  getSubscription,
);

/**
 * POST /api/payments/cancel
 * Cancel active subscription.
 * Body: { emailToken } — Paystack sends this token to the customer's email.
 */
router.post(
  '/cancel',
  authenticate,
  requireRole('ARTISAN'),
  cancelPlan,
);

module.exports = router;
