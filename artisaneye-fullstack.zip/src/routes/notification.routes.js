const express = require('express');
const { listNotifications, markRead, markAllRead } = require('../controllers/notification.controller');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

// All notification routes require auth
router.use(authenticate);

/**
 * GET /api/notifications
 * Query: ?page=1&limit=20&unreadOnly=true
 */
router.get('/', listNotifications);

/**
 * PATCH /api/notifications/:id/read
 */
router.patch('/:id/read', markRead);

/**
 * PATCH /api/notifications/read-all
 */
router.patch('/read-all', markAllRead);

module.exports = router;
