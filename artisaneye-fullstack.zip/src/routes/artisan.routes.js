const express = require('express');
const { body } = require('express-validator');

const {
  getMe, updateMe, getAll, getById,
  addPhotos, deletePhoto,
} = require('../controllers/artisan.controller');

const { authenticate, requireRole } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { uploadMiddleware } = require('../utils/cloudinary');
const userRateLimit = require('../middleware/userRateLimit');

const router = express.Router();

// ─── Validation ────────────────────────────────────────────────────────

const updateProfileRules = [
  body('trade').optional().isArray({ min: 1 }).withMessage('Trade must be a non-empty array.'),
  body('city').optional().trim().notEmpty().withMessage('City cannot be blank.'),
  body('bio').optional().isLength({ max: 800 }).withMessage('Bio must be 800 characters or fewer.'),
  body('yearsExperience').optional().isInt({ min: 0, max: 60 }).withMessage('Years experience must be 0–60.'),
  body('startingRate').optional().trim(),
  body('languages').optional().isArray(),
  body('serviceArea').optional().trim(),
];

// ─── Routes ────────────────────────────────────────────────────────────

/** GET /api/artisans — public search */
router.get('/', userRateLimit(60, 60), getAll);

/** GET /api/artisans/me — own profile (ARTISAN only) */
router.get('/me', authenticate, requireRole('ARTISAN'), getMe);

/** PATCH /api/artisans/me — update own profile (ARTISAN only) */
router.patch('/me', authenticate, requireRole('ARTISAN'), updateProfileRules, validate, updateMe);

/**
 * POST /api/artisans/me/request-verification
 * ARTISAN only — sets verificationStatus to PENDING and notifies the admin inbox.
 */
router.post('/me/request-verification', authenticate, requireRole('ARTISAN'), async (req, res, next) => {
  try {
    const prisma = require('../config/prisma');
    const { ok, badRequest } = require('../utils/response');
    const { sendMail } = require('../utils/mailer');

    const profile = await prisma.artisanProfile.findUnique({ where: { userId: req.user.id } });
    if (!profile) return res.status(404).json({ success: false, message: 'Profile not found.' });

    if (profile.verificationStatus === 'VERIFIED') {
      return badRequest(res, 'Your profile is already verified.');
    }
    if (profile.verificationStatus === 'PENDING') {
      return badRequest(res, 'Your verification is already pending review.');
    }

    await prisma.artisanProfile.update({
      where: { userId: req.user.id },
      data:  { verificationStatus: 'PENDING' },
    });

    // Notify support inbox so admin sees it in the verification queue
    try {
      const user = await prisma.user.findUnique({ where: { id: req.user.id } });
      await sendMail({
        to:      process.env.SUPPORT_EMAIL || process.env.EMAIL_FROM || 'support@artisaneye.com',
        subject: `[Verification Request] ${user.fullName}`,
        html:    `<p><strong>${user.fullName}</strong> (${user.email}) has requested profile verification.</p><p>Profile ID: <code>${profile.id}</code></p><p>Review at: <a href="${process.env.APP_URL}/admin.html">Admin dashboard</a></p>`,
        text:    `${user.fullName} (${user.email}) requested verification. Profile ID: ${profile.id}`,
      });
    } catch (e) { console.warn('[verify-request] email failed:', e.message); }

    return ok(res, {}, 'Verification request submitted. Our team will review within 48 hours.');
  } catch (err) { next(err); }
});

/** POST /api/artisans/me/photos — upload work photos to Cloudinary */
router.post(
  '/me/photos',
  authenticate,
  requireRole('ARTISAN'),
  uploadMiddleware.array('photos', 10),
  addPhotos,
);

/** DELETE /api/artisans/me/photos/:photoId — delete own photo */
router.delete('/me/photos/:photoId', authenticate, requireRole('ARTISAN'), deletePhoto);

/** GET /api/artisans/:id — public profile */
router.get('/:id', getById);

/**
 * POST /api/artisans/:id/reviews — REMOVED.
 * Reviews are now tied to confirmed jobs.
 * Use POST /api/jobs/:jobId/review instead.
 */
router.post('/:id/reviews', (req, res) => {
  res.status(410).json({
    success: false,
    message: 'This endpoint has been removed. Reviews must be submitted via POST /api/jobs/:jobId/review after a job is confirmed.',
  });
});

module.exports = router;
