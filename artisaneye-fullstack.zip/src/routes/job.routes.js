const express = require('express');
const { body } = require('express-validator');

const {
  createJob, listJobs, getJob,
  updateJobStatus, leaveReview,
} = require('../controllers/job.controller');

const { authenticate, requireRole } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const userRateLimit = require('../middleware/userRateLimit');

const router = express.Router();

// All job routes require auth
router.use(authenticate);

// ─── Validation ────────────────────────────────────────────────────────

const createJobRules = [
  body('artisanUserId').notEmpty().isUUID().withMessage('Valid artisanUserId is required.'),
  body('title').trim().notEmpty().isLength({ max: 120 }).withMessage('Title is required (max 120 chars).'),
  body('description').trim().notEmpty().isLength({ max: 2000 }).withMessage('Description is required (max 2000 chars).'),
  body('agreedPrice').optional().trim().isLength({ max: 80 }),
  body('scheduledAt').optional().isISO8601().withMessage('scheduledAt must be a valid date.'),
];

const statusRules = [
  body('status').notEmpty().withMessage('status is required.'),
  body('cancelReason').optional().isLength({ max: 500 }),
];

const reviewRules = [
  body('rating').isInt({ min: 1, max: 5 }).withMessage('rating must be 1–5.'),
  body('comment').optional().isLength({ max: 1000 }).withMessage('Comment must be ≤1000 chars.'),
];

// ─── Routes ────────────────────────────────────────────────────────────

/**
 * POST /api/jobs
 * CLIENT only — create a new job request.
 */
router.post('/', requireRole('CLIENT'), userRateLimit(60, 10), createJobRules, validate, createJob);

/**
 * GET /api/jobs
 * List jobs for the authenticated user.
 * Query: ?status=PENDING&page=1&limit=20
 */
router.get('/', listJobs);

/**
 * GET /api/jobs/:id
 * Get a single job (participants only).
 */
router.get('/:id', getJob);

/**
 * PATCH /api/jobs/:id/status
 * Transition job status — enforced by state machine per role.
 * Body: { status, cancelReason? }
 */
router.patch('/:id/status', statusRules, validate, updateJobStatus);

/**
 * POST /api/jobs/:id/review
 * CLIENT only — leave a review after job is CONFIRMED.
 * Body: { rating, comment? }
 */
router.post('/:id/review', requireRole('CLIENT'), reviewRules, validate, leaveReview);

module.exports = router;
