const express = require('express');
const { body } = require('express-validator');

const {
  startThread, listThreads, getThread,
  sendMessage, markRead, deleteMessage,
} = require('../controllers/message.controller');

const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

const router = express.Router();

// All messaging routes require authentication
router.use(authenticate);

// ─── Validation rules ──────────────────────────────────────────────────

const startThreadRules = [
  body('artisanUserId')
    .notEmpty().withMessage('artisanUserId is required.')
    .isUUID().withMessage('artisanUserId must be a valid UUID.'),
];

const sendMessageRules = [
  body('body')
    .notEmpty().withMessage('Message body cannot be empty.')
    .isLength({ max: 4000 }).withMessage('Message must be 4000 characters or fewer.'),
];

// ─── Routes ────────────────────────────────────────────────────────────

/**
 * POST /api/messages/threads
 * Start or retrieve a conversation with an artisan.
 * CLIENT only (artisans can reply but clients initiate).
 * Body: { artisanUserId }
 */
router.post('/threads', startThreadRules, validate, startThread);

/**
 * GET /api/messages/threads
 * List all threads for the authenticated user.
 * Works for both CLIENT and ARTISAN.
 */
router.get('/threads', listThreads);

/**
 * GET /api/messages/threads/:threadId
 * Full thread + paginated messages.
 * Query: ?page=1&limit=30
 */
router.get('/threads/:threadId', getThread);

/**
 * POST /api/messages/threads/:threadId
 * Send a message in a thread.
 * Body: { body }
 */
router.post('/threads/:threadId', sendMessageRules, validate, sendMessage);

/**
 * PATCH /api/messages/threads/:threadId/read
 * Mark all unread messages in a thread as read.
 */
router.patch('/threads/:threadId/read', markRead);

/**
 * DELETE /api/messages/threads/:threadId/messages/:messageId
 * Redact own message (within 10 minutes of sending).
 */
router.delete('/threads/:threadId/messages/:messageId', deleteMessage);

module.exports = router;
