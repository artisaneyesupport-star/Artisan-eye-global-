const express = require('express');
const { body } = require('express-validator');
const { validate } = require('../middleware/validate');
const { sendMail } = require('../utils/mailer');
const { ok, serverError } = require('../utils/response');

const router = express.Router();

const contactRules = [
  body('name').trim().notEmpty().isLength({ max: 100 }).withMessage('Name is required.'),
  body('email').trim().isEmail().normalizeEmail().withMessage('Valid email is required.'),
  body('subject').trim().notEmpty().isLength({ max: 200 }).withMessage('Subject is required.'),
  body('message').trim().notEmpty().isLength({ max: 3000 }).withMessage('Message is required.'),
  body('reason').optional().trim().isLength({ max: 60 }),
];

/**
 * POST /api/contact
 * Public — sends contact form email to support inbox.
 * Body: { name, email, subject, message, reason? }
 */
router.post('/', contactRules, validate, async (req, res, next) => {
  try {
    const { name, email, subject, message, reason = 'general' } = req.body;

    const html = `
      <div style="font-family:Arial,sans-serif; max-width:600px; margin:0 auto; padding:24px;">
        <h2 style="color:#1B3A5C;">New contact form submission</h2>
        <table style="width:100%; border-collapse:collapse; font-size:14px;">
          <tr><td style="padding:8px; color:#888; width:120px;">From</td><td style="padding:8px; font-weight:700;">${name} &lt;${email}&gt;</td></tr>
          <tr><td style="padding:8px; color:#888;">Reason</td><td style="padding:8px;">${reason}</td></tr>
          <tr><td style="padding:8px; color:#888;">Subject</td><td style="padding:8px;">${subject}</td></tr>
        </table>
        <hr style="border:none; border-top:1px solid #ddd; margin:16px 0;">
        <p style="white-space:pre-wrap; color:#333; line-height:1.65;">${message}</p>
        <hr style="border:none; border-top:1px solid #ddd; margin:16px 0;">
        <p style="font-size:12px; color:#aaa;">Reply directly to this email to respond to ${name}.</p>
      </div>
    `;

    await sendMail({
      to:       process.env.SUPPORT_EMAIL || process.env.EMAIL_FROM || 'support@artisaneye.com',
      replyTo:  email,
      subject:  `[Contact: ${reason}] ${subject}`,
      html,
      text:     `From: ${name} <${email}>\nReason: ${reason}\nSubject: ${subject}\n\n${message}`,
    });

    // Send acknowledgement to the sender
    await sendMail({
      to:      email,
      subject: 'We got your message — ArtisanEye',
      html: `
        <div style="font-family:Arial,sans-serif; max-width:560px; margin:0 auto; padding:32px;">
          <h2 style="color:#1B3A5C;">Thanks for reaching out, ${name.split(' ')[0]}.</h2>
          <p style="color:#444; line-height:1.65;">We received your message and will reply within one business day.</p>
          <p style="color:#888; font-size:13px;">Your message: <em>"${subject}"</em></p>
          <p style="color:#888; font-size:12px; margin-top:32px;">ArtisanEye Support · Lagos, Nigeria</p>
        </div>
      `,
      text: `Thanks ${name.split(' ')[0]}! We got your message and will reply within one business day.`,
    });

    return ok(res, {}, 'Message sent. We\'ll reply within one business day.');
  } catch (err) { next(err); }
});

module.exports = router;
