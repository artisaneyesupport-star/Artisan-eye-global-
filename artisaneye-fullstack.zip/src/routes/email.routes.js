const express = require('express');
const { body } = require('express-validator');

const {
  sendVerification,
  verifyEmail,
  forgotPassword,
  resetPassword,
} = require('../controllers/email.controller');

const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

const router = express.Router();

// ─── Validation rules ──────────────────────────────────────────────────

const forgotRules = [
  body('email')
    .trim()
    .notEmpty().withMessage('Email is required.')
    .isEmail().withMessage('Must be a valid email address.')
    .normalizeEmail(),
];

const resetRules = [
  body('token')
    .notEmpty().withMessage('Reset token is required.'),
  body('password')
    .notEmpty().withMessage('Password is required.')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters.')
    .matches(/[A-Z]/).withMessage('Must contain at least one uppercase letter.')
    .matches(/[0-9]/).withMessage('Must contain at least one number.'),
];

// ─── Routes ────────────────────────────────────────────────────────────

/**
 * POST /api/email/send-verification
 * Works authenticated (logged-in user resending) OR unauthenticated ({ email } in body).
 * Always returns success to prevent email enumeration.
 */
router.post('/send-verification', (req, res, next) => {
  // Try auth if token present, but don't block unauthenticated resends
  if (req.headers.authorization || req.cookies?.refreshToken) {
    return authenticate(req, res, () => sendVerification(req, res, next));
  }
  return sendVerification(req, res, next);
});

/**
 * GET /api/email/verify?token=xxx
 * Public — validates token from email link and marks email as verified.
 */
router.get('/verify', verifyEmail);

/**
 * POST /api/email/forgot-password
 * Public — sends password reset email.
 * Body: { email }
 */
router.post('/forgot-password', forgotRules, validate, forgotPassword);

/**
 * POST /api/email/reset-password
 * Public — resets password using token from email.
 * Body: { token, password }
 */
router.post('/reset-password', resetRules, validate, resetPassword);

module.exports = router;
