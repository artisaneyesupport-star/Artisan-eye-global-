const express = require('express');
const rateLimit = require('express-rate-limit');

const { register, login, refresh, logout, me } = require('../controllers/auth.controller');
const { authenticate } = require('../middleware/auth');
const { validate, registerRules, loginRules } = require('../middleware/validate');

const router = express.Router();

// ─── Rate limiting — stricter on auth endpoints ────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20,
  message: { success: false, message: 'Too many attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ─── Routes ───────────────────────────────────────────────────────────

/**
 * POST /api/auth/register
 * Body: { fullName, email, password, role?, phone? }
 * Returns: { accessToken, user }  +  sets refreshToken cookie
 */
router.post('/register', authLimiter, registerRules, validate, register);

/**
 * POST /api/auth/login
 * Body: { email, password }
 * Returns: { accessToken, user }  +  sets refreshToken cookie
 */
router.post('/login', authLimiter, loginRules, validate, login);

/**
 * POST /api/auth/refresh
 * Reads HttpOnly cookie: refreshToken
 * Returns: { accessToken }  +  rotates refreshToken cookie
 */
router.post('/refresh', refresh);

/**
 * POST /api/auth/logout
 * Revokes refresh token in DB and clears the cookie
 */
router.post('/logout', logout);

/**
 * GET /api/auth/me
 * Protected — requires Bearer access token
 * Returns: { user }
 */
router.get('/me', authenticate, me);

module.exports = router;
