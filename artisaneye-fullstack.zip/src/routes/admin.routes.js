const express = require('express');
const { body } = require('express-validator');

const {
  getVerificationQueue,
  approveVerification,
  rejectVerification,
  listUsers,
  getStats,
  resolveDispute,
} = require('../controllers/admin.controller');

const { authenticate, requireRole } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

const router = express.Router();

// ALL admin routes require authentication + ADMIN role
router.use(authenticate, requireRole('ADMIN'));

// ─── Validation ────────────────────────────────────────────────────────

const rejectRules = [
  body('reason').optional().isLength({ max: 500 }).withMessage('Reason must be ≤500 chars.'),
];

const resolveRules = [
  body('resolution').notEmpty().withMessage('resolution note is required.'),
  body('outcome').isIn(['CONFIRMED', 'CANCELLED']).withMessage('outcome must be CONFIRMED or CANCELLED.'),
];

// ─── Routes ────────────────────────────────────────────────────────────

/**
 * GET /api/admin/stats
 * Platform-level overview numbers.
 */
router.get('/stats', getStats);

/**
 * GET /api/admin/users
 * List all users with optional search/role filter.
 * Query: ?role=ARTISAN&search=chidi&page=1&limit=20
 */
router.get('/users', listUsers);

/**
 * GET /api/admin/verification-queue
 * Artisan profiles awaiting verification review.
 */
router.get('/verification-queue', getVerificationQueue);

/**
 * PATCH /api/admin/verification/:profileId/approve
 * Approve an artisan's verification — sends approval email.
 */
router.patch('/verification/:profileId/approve', approveVerification);

/**
 * PATCH /api/admin/verification/:profileId/reject
 * Reject with optional reason — sends rejection email.
 * Body: { reason? }
 */
router.patch('/verification/:profileId/reject', rejectRules, validate, rejectVerification);

/**
 * GET /api/admin/jobs
 * List ALL jobs across the platform — admin only.
 * Query: ?status=DISPUTED&page=1&limit=20
 */
router.get('/jobs', async (req, res, next) => {
  try {
    const prisma = require('../config/prisma');
    const { ok } = require('../utils/response');
    const { status, page = '1', limit = '20' } = req.query;
    const pageNum  = Math.max(1, parseInt(page));
    const pageSize = Math.min(100, parseInt(limit));
    const where = status ? { status } : {};

    const [jobs, total] = await Promise.all([
      prisma.job.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (pageNum - 1) * pageSize,
        take: pageSize,
        include: {
          client:  { select: { id: true, fullName: true, email: true } },
          artisan: { select: { id: true, fullName: true, email: true } },
          review:  true,
        },
      }),
      prisma.job.count({ where }),
    ]);

    return ok(res, {
      jobs,
      pagination: { page: pageNum, limit: pageSize, total, pages: Math.ceil(total / pageSize) },
    });
  } catch (err) { next(err); }
});

/**
 * GET /api/admin/backups
 * List available database backups.
 */
router.get('/backups', async (req, res, next) => {
  try {
    const { listBackups } = require('../utils/backup');
    const { ok } = require('../utils/response');
    const backups = listBackups();
    return ok(res, { backups, count: backups.length });
  } catch (err) { next(err); }
});

/**
 * POST /api/admin/backups/run
 * Trigger a manual backup immediately.
 */
router.post('/backups/run', async (req, res, next) => {
  try {
    const { runBackup } = require('../utils/backup');
    const { ok, serverError } = require('../utils/response');
    const result = await runBackup();
    if (result.success) return ok(res, result, 'Backup completed.');
    return serverError(res, result.error || result.reason || 'Backup failed.');
  } catch (err) { next(err); }
});

/**
 * PATCH /api/admin/jobs/:id/resolve-dispute
 * Admin resolves a disputed job.
 * Body: { resolution, outcome: "CONFIRMED" | "CANCELLED" }
 */
router.patch('/jobs/:id/resolve-dispute', resolveRules, validate, resolveDispute);

module.exports = router;
