const { PrismaClient } = require('@prisma/client');

// Reuse a single PrismaClient instance across all modules
// (prevents connection pool exhaustion in development with hot reload)
const prisma = new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'warn', 'error'] : ['error'],
});

module.exports = prisma;
