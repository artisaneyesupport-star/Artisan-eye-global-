const { Server } = require('socket.io');
const { verifyAccessToken } = require('../utils/jwt');
const prisma = require('../config/prisma');

/**
 * initSocket — attaches Socket.io to the HTTP server.
 * Call this in index.js after creating the HTTP server.
 *
 * Architecture:
 *  - Each thread has its own Socket.io room: "thread:<threadId>"
 *  - On connect, client sends their access token for authentication
 *  - Server verifies the token, then the client can join thread rooms
 *  - Only verified participants of a thread can join its room
 *
 * Events (client → server):
 *  - thread:join   { threadId }          → join a thread room
 *  - thread:leave  { threadId }          → leave a thread room
 *  - thread:typing { threadId }          → broadcast typing indicator
 *
 * Events (server → client):
 *  - message:new     <Message>           → new message in a thread
 *  - message:deleted { messageId }       → message was redacted
 *  - messages:read   { threadId, readBy} → messages marked read
 *  - user:typing     { threadId, userId, fullName } → typing indicator
 *  - error           { message }         → socket-level error
 */
function initSocket(httpServer, corsOptions) {
  const io = new Server(httpServer, {
    cors: corsOptions,
    // Reconnection is handled client-side by socket.io-client
    pingTimeout: 60000,
    pingInterval: 25000,
  });

  // ─── Auth middleware ────────────────────────────────────────────────
  // Runs once per connection before any events are processed.

  io.use(async (socket, next) => {
    try {
      const token =
        socket.handshake.auth?.token ||
        socket.handshake.headers?.authorization?.split(' ')[1];

      if (!token) return next(new Error('AUTH_MISSING'));

      const payload = verifyAccessToken(token);
      const user = await prisma.user.findUnique({
        where: { id: payload.id },
        select: { id: true, fullName: true, role: true },
      });

      if (!user) return next(new Error('AUTH_USER_NOT_FOUND'));

      socket.user = user;   // attach to socket for use in event handlers
      next();
    } catch (err) {
      next(new Error('AUTH_INVALID_TOKEN'));
    }
  });

  // ─── Connection handler ─────────────────────────────────────────────

  io.on('connection', (socket) => {
    const { id: userId, fullName, role } = socket.user;
    console.log(`[socket] connected  user=${userId} (${role})`);

    // Auto-join a personal room so we can push notifications to specific users
    socket.join(`user:${userId}`);

    // ── thread:join ──────────────────────────────────────────────────
    socket.on('thread:join', async ({ threadId }) => {
      try {
        if (!threadId) return socket.emit('error', { message: 'threadId is required.' });

        const thread = await prisma.thread.findUnique({ where: { id: threadId } });
        if (!thread) return socket.emit('error', { message: 'Thread not found.' });

        // Only the two participants may join
        if (thread.clientId !== userId && thread.artisanId !== userId) {
          return socket.emit('error', { message: 'Not a participant in this thread.' });
        }

        socket.join(`thread:${threadId}`);
        console.log(`[socket] user=${userId} joined thread=${threadId}`);
      } catch (err) {
        socket.emit('error', { message: 'Could not join thread.' });
      }
    });

    // ── thread:leave ─────────────────────────────────────────────────
    socket.on('thread:leave', ({ threadId }) => {
      socket.leave(`thread:${threadId}`);
      console.log(`[socket] user=${userId} left thread=${threadId}`);
    });

    // ── thread:typing ────────────────────────────────────────────────
    // Broadcasts to everyone else in the thread room.
    socket.on('thread:typing', ({ threadId }) => {
      socket
        .to(`thread:${threadId}`)
        .emit('user:typing', { threadId, userId, fullName });
    });

    // ── disconnect ───────────────────────────────────────────────────
    socket.on('disconnect', (reason) => {
      console.log(`[socket] disconnected user=${userId} reason=${reason}`);
    });
  });

  return io;
}

module.exports = initSocket;
