/**
 * sentry.js
 * ==========
 * Sentry error monitoring for the ArtisanEye backend.
 *
 * Setup:
 *   npm install @sentry/node
 *   Add to .env: SENTRY_DSN=https://xxx@xxx.ingest.sentry.io/xxx
 *
 * Get your DSN at: https://sentry.io → New Project → Node.js → copy DSN
 *
 * Usage:
 *   const { initSentry, sentryErrorHandler } = require('./config/sentry');
 *   initSentry(app);           ← call before routes in app.js
 *   app.use(sentryErrorHandler); ← call after routes, before errorHandler
 */

let Sentry = null;

function initSentry(app) {
  if (!process.env.SENTRY_DSN) {
    console.log('[sentry] SENTRY_DSN not set — error monitoring disabled');
    return;
  }

  try {
    Sentry = require('@sentry/node');

    Sentry.init({
      dsn:         process.env.SENTRY_DSN,
      environment: process.env.NODE_ENV || 'development',
      // Only send errors in production to avoid noise during development
      enabled:     process.env.NODE_ENV === 'production',
      // Capture 10% of transactions for performance monitoring
      tracesSampleRate: 0.1,
      // Don't send personal data in request bodies
      beforeSend(event) {
        if (event.request?.data) {
          // Scrub sensitive fields
          const scrub = ['password', 'passwordHash', 'token', 'secret', 'apiKey'];
          if (typeof event.request.data === 'object') {
            scrub.forEach(key => {
              if (event.request.data[key]) event.request.data[key] = '[Filtered]';
            });
          }
        }
        return event;
      },
    });

    // Instrument Express — must be called before defining routes
    Sentry.setupExpressErrorHandler(app);

    console.log('[sentry] Error monitoring active');
  } catch (err) {
    console.warn('[sentry] Could not initialise — is @sentry/node installed?', err.message);
  }
}

/**
 * Express error handler middleware for Sentry.
 * Must be placed AFTER all routes but BEFORE your own errorHandler.
 */
function sentryErrorHandler(err, req, res, next) {
  if (Sentry) {
    Sentry.captureException(err);
  }
  next(err);
}

/**
 * Manually capture an exception (use in catch blocks for expected errors
 * you still want visibility on).
 */
function captureException(err, context = {}) {
  if (Sentry) {
    Sentry.withScope(scope => {
      Object.entries(context).forEach(([key, val]) => scope.setExtra(key, val));
      Sentry.captureException(err);
    });
  }
}

module.exports = { initSentry, sentryErrorHandler, captureException };
