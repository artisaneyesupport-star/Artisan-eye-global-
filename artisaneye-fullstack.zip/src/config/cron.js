/**
 * cron.js
 * ========
 * Lightweight scheduled tasks using node-cron.
 * Call initCron(prisma) once from index.js after DB connects.
 *
 * Tasks:
 *   - Nightly at 02:00 WAT: purge expired/revoked refresh tokens
 *   - Nightly at 02:15 WAT: expire stale password reset + email verification tokens
 *   - Nightly at 02:30 WAT: downgrade artisans with expired subscriptions
 *
 * Install: npm install node-cron
 */

const cron = require('node-cron');
const { runBackup } = require('../utils/backup');

function initCron(prisma) {
  // ── 1. Purge expired / revoked refresh tokens ───────────────────────
  // Runs nightly at 02:00 server time
  cron.schedule('0 2 * * *', async () => {
    try {
      const { count } = await prisma.refreshToken.deleteMany({
        where: {
          OR: [
            { expiresAt: { lt: new Date() } },
            { revoked: true },
          ],
        },
      });
      console.log(`[cron] Purged ${count} stale refresh tokens`);
    } catch (err) {
      console.error('[cron] Token purge failed:', err.message);
    }
  });

  // ── 2. Clean up stale email + password tokens ───────────────────────
  // Runs nightly at 02:15
  cron.schedule('15 2 * * *', async () => {
    try {
      const cutoff = new Date();

      const [emailCount, resetCount] = await Promise.all([
        prisma.emailVerification.deleteMany({
          where: {
            OR: [
              { expiresAt: { lt: cutoff } },
              { usedAt:    { not: null } },
            ],
          },
        }),
        prisma.passwordReset.deleteMany({
          where: {
            OR: [
              { expiresAt: { lt: cutoff } },
              { usedAt:    { not: null } },
            ],
          },
        }),
      ]);

      console.log(
        `[cron] Purged ${emailCount.count} email tokens, ` +
        `${resetCount.count} password reset tokens`
      );
    } catch (err) {
      console.error('[cron] Token cleanup failed:', err.message);
    }
  });

  // ── 3. Downgrade expired subscriptions ─────────────────────────────
  // Runs nightly at 02:30 — catches any subscriptions Paystack webhook missed
  cron.schedule('30 2 * * *', async () => {
    try {
      // Find active subscriptions whose billing period has ended
      const expired = await prisma.subscription.findMany({
        where: {
          status:          'ACTIVE',
          currentPeriodEnd: { lt: new Date() },
        },
        select: { id: true, userId: true },
      });

      if (expired.length === 0) {
        console.log('[cron] No expired subscriptions to process');
        return;
      }

      const userIds = expired.map(s => s.userId);

      await Promise.all([
        prisma.subscription.updateMany({
          where: { id: { in: expired.map(s => s.id) } },
          data:  { status: 'EXPIRED' },
        }),
        prisma.artisanProfile.updateMany({
          where: { userId: { in: userIds } },
          data:  { plan: 'STARTER' },
        }),
      ]);

      console.log(`[cron] Downgraded ${expired.length} expired subscriptions to STARTER`);
    } catch (err) {
      console.error('[cron] Subscription expiry check failed:', err.message);
    }
  });

  // ── 4. Nightly database backup ──────────────────────────────────────
  // Runs at 03:00 — after token cleanup, keeping last 7 days
  cron.schedule('0 3 * * *', async () => {
    const result = await runBackup();
    if (!result.success) {
      console.error('[cron] Backup failed:', result.error || result.reason);
    }
  });

  console.log('[cron] Scheduled tasks initialized');
}

module.exports = initCron;
