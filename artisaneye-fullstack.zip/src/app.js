const express    = require('express');
const helmet     = require('helmet');
const cors       = require('cors');
const cookieParser = require('cookie-parser');
const morgan     = require('morgan');
const rateLimit  = require('express-rate-limit');
const path       = require('path');

// ─── Routes ───────────────────────────────────────────────────────────
const authRoutes    = require('./routes/auth.routes');
const artisanRoutes = require('./routes/artisan.routes');
const messageRoutes = require('./routes/message.routes');
const paymentRoutes = require('./routes/payment.routes');
const emailRoutes   = require('./routes/email.routes');
const jobRoutes     = require('./routes/job.routes');
const adminRoutes   = require('./routes/admin.routes');
const contactRoutes = require('./routes/contact.routes');
const notificationRoutes = require('./routes/notification.routes');

// ─── Middleware ───────────────────────────────────────────────────────
const errorHandler                           = require('./middleware/errorHandler');
const { sanitizeBody }                       = require('./middleware/sanitize');
const { httpsRedirect, securityHeaders, TRUST_PROXY } = require('./middleware/security');
const { initSentry, sentryErrorHandler }     = require('./config/sentry');

const app = express();

// Trust reverse proxy (Nginx, Railway, Render, etc.)
app.set('trust proxy', TRUST_PROXY);

// Sentry must be initialised before any routes
initSentry(app);

// ─── HTTPS redirect (production only) ─────────────────────────────────
app.use(httpsRedirect);

// ─── Security headers ─────────────────────────────────────────────────
// Configure Helmet CSP to allow inline scripts/styles used in our HTML pages.
// The frontend uses inline <script> and <style> tags throughout.
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:     ["'self'"],
      scriptSrc:      [
        "'self'",
        "'unsafe-inline'",          // inline <script> tags in HTML pages
        'https://cdn.socket.io',    // Socket.io CDN
        'https://browser.sentry-cdn.com', // Sentry CDN
        'https://js.paystack.co',   // Paystack inline checkout
      ],
      styleSrc:       ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc:        ["'self'", 'https://fonts.gstatic.com'],
      imgSrc:         ["'self'", 'data:', 'https://res.cloudinary.com', 'blob:'],
      connectSrc:     [
        "'self'",
        'wss:',                     // WebSocket (Socket.io)
        'https://api.paystack.co',  // Paystack API
        'https://sentry.io',        // Sentry
        'https://*.ingest.sentry.io',
      ],
      frameSrc:       ["'none'"],
      objectSrc:      ["'none'"],
      upgradeInsecureRequests: process.env.NODE_ENV === 'production' ? [] : null,
    },
  },
  crossOriginEmbedderPolicy: false, // allows Cloudinary images to load
}));
app.use(securityHeaders);

// ─── CORS ─────────────────────────────────────────────────────────────
// When frontend is served by the same Express server, same-origin requests
// have no Origin header and are always allowed. We also allow FRONTEND_URL
// and localhost variants for development.
const PORT = process.env.PORT || 4000;
app.use(cors({
  origin: (origin, callback) => {
    const allowed = [
      process.env.FRONTEND_URL,
      `http://localhost:${PORT}`,
      'http://localhost:3000',
    ].filter(Boolean);
    if (!origin || allowed.includes(origin)) callback(null, true);
    else callback(new Error(`CORS: origin ${origin} not allowed`));
  },
  credentials: true,
}));

// ─── Body parsers ─────────────────────────────────────────────────────
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser());

// ─── Input sanitization (XSS protection) ──────────────────────────────
app.use(sanitizeBody);

// ─── Request logging (dev only) ───────────────────────────────────────
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// ─── Global rate limit ─────────────────────────────────────────────────
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests — please slow down.' },
}));

// ─── Health check ─────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status:    'ok',
    timestamp: new Date().toISOString(),
    env:       process.env.NODE_ENV || 'development',
  });
});

// ─── API routes ───────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/artisans', artisanRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/email',    emailRoutes);
app.use('/api/jobs',     jobRoutes);
app.use('/api/admin',    adminRoutes);
app.use('/api/contact',  contactRoutes);
app.use('/api/notifications', notificationRoutes);

// ─── Static frontend files ─────────────────────────────────────────────
// Serve the /public folder (built frontend) on the same server as the API.
// API routes (/api/*) take priority — this only handles non-API requests.
const PUBLIC_DIR = path.join(__dirname, '../public');
app.use(express.static(PUBLIC_DIR, {
  maxAge:  process.env.NODE_ENV === 'production' ? '1h' : 0,
  // Don't cache HTML — always fetch fresh
  setHeaders: (res, filePath) => {
    if (filePath.endsWith('.html')) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    }
  },
}));

// ─── 404 for unknown API routes ───────────────────────────────────────
app.use('/api/*', (req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.method} ${req.path} not found.` });
});

// ─── HTML5 fallback — serve correct page or 404 ───────────────────────
app.use((req, res) => {
  const htmlFile = req.path.endsWith('.html') ? req.path.slice(1) : null;
  const filePath = htmlFile
    ? path.join(PUBLIC_DIR, htmlFile)
    : null;

  // If a specific .html was requested and exists, serve it
  if (filePath) {
    const fs = require('fs');
    if (fs.existsSync(filePath)) {
      return res.sendFile(filePath);
    }
    return res.status(404).sendFile(path.join(PUBLIC_DIR, '404.html'));
  }

  // For non-.html paths (e.g. /dashboard, /browse), serve 404.html with 404
  // since the frontend uses explicit .html extensions (browse.html, not /browse)
  return res.status(404).sendFile(path.join(PUBLIC_DIR, '404.html'));
});

// ─── Global error handler ─────────────────────────────────────────────
app.use(sentryErrorHandler); // must come before errorHandler
app.use(errorHandler);

module.exports = app;
