# Prisma Migrations

This folder is managed by Prisma. 

## First-time setup on a new database

If you are deploying for the first time and have no migration files yet, run:

```bash
# Generates the initial migration SQL from your schema
npx prisma migrate dev --name init
```

This will create a timestamped migration folder (e.g. `20260101000000_init/migration.sql`)
that records the full database schema. Commit this folder to your repo.

Then in production, `npx prisma migrate deploy` applies all pending migrations safely.

## Why there are no migration files yet

Migration files are generated from your local PostgreSQL database.
You must run `npx prisma migrate dev --name init` locally after setting up
your `.env` with a real `DATABASE_URL` to generate them.

See the DEPLOY.md Step 2 for the full workflow.
