/**
 * ArtisanEye — Database Seed
 * Run: node prisma/seed.js
 *
 * Creates:
 *  - 1 admin user
 *  - 1 test client
 *  - 8 test artisans (mix of verified/unverified/pending, Starter/Pro)
 *  - Sample jobs across all statuses
 *  - Reviews tied to CONFIRMED jobs
 *  - Sample message threads
 */

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

// ── Production guard ───────────────────────────────────────────────────
// Prevent accidentally seeding a live production database with test accounts.
if (process.env.NODE_ENV === 'production') {
  const confirmed = process.env.SEED_PRODUCTION === 'yes_i_know_what_im_doing';
  if (!confirmed) {
    console.error('\n❌  Refusing to seed a production database.');
    console.error('   This would create test accounts with known passwords.');
    console.error('   If you really need to run seed on production, set:');
    console.error('   SEED_PRODUCTION=yes_i_know_what_im_doing\n');
    process.exit(1);
  }
  console.warn('⚠️   Seeding production database — this was explicitly confirmed.\n');
}

const ARTISANS = [
  { name: 'Chidi Okonkwo',  email: 'chidi@test.com',   trade: ['Plumbing'],    city: 'Lagos',         years: 11, rate: 'From ₦6,000',  rating: 4.9, jobs: 3, verified: 'VERIFIED',   plan: 'PRO'     },
  { name: 'Aisha Bello',    email: 'aisha@test.com',    trade: ['Electrical'],  city: 'Lagos',         years: 7,  rate: 'From ₦7,500',  rating: 4.8, jobs: 2, verified: 'VERIFIED',   plan: 'STARTER' },
  { name: 'Emeka Nwosu',    email: 'emeka@test.com',    trade: ['Carpentry'],   city: 'Abuja',         years: 9,  rate: 'From ₦8,000',  rating: 4.7, jobs: 1, verified: 'VERIFIED',   plan: 'STARTER' },
  { name: 'Folake Adeyemi', email: 'folake@test.com',   trade: ['Tailoring'],   city: 'Lagos',         years: 15, rate: 'From ₦4,000',  rating: 5.0, jobs: 2, verified: 'VERIFIED',   plan: 'PRO'     },
  { name: 'Ibrahim Sani',   email: 'ibrahim@test.com',  trade: ['Masonry'],     city: 'Port Harcourt', years: 6,  rate: 'From ₦10,000', rating: 0,   jobs: 0, verified: 'PENDING',    plan: 'STARTER' },
  { name: 'Ngozi Eze',      email: 'ngozi@test.com',    trade: ['Painting'],    city: 'Lagos',         years: 8,  rate: 'From ₦5,500',  rating: 4.7, jobs: 1, verified: 'VERIFIED',   plan: 'STARTER' },
  { name: 'Blessing Udo',   email: 'blessing@test.com', trade: ['Electrical'],  city: 'Lagos',         years: 10, rate: 'From ₦7,000',  rating: 4.9, jobs: 2, verified: 'VERIFIED',   plan: 'PRO'     },
  { name: 'Grace Effiong',  email: 'grace@test.com',    trade: ['Painting'],    city: 'Accra',         years: 5,  rate: 'From ₦5,000',  rating: 0,   jobs: 0, verified: 'UNVERIFIED', plan: 'STARTER' },
];

async function main() {
  console.log('🌱  Seeding database…\n');

  const passwordHash = await bcrypt.hash('Password123!', 12);

  // ── Admin ─────────────────────────────────────────────────────────────
  const admin = await prisma.user.upsert({
    where: { email: 'admin@artisaneye.com' },
    update: {},
    create: {
      email: 'admin@artisaneye.com',
      passwordHash,
      fullName: 'ArtisanEye Admin',
      role: 'ADMIN',
      emailVerified: true,
    },
  });
  console.log(`✅  Admin:   ${admin.email}`);

  // ── Client ────────────────────────────────────────────────────────────
  const client = await prisma.user.upsert({
    where: { email: 'client@test.com' },
    update: {},
    create: {
      email: 'client@test.com',
      passwordHash,
      fullName: 'Tola Adeyemi',
      role: 'CLIENT',
      phone: '+2348011111111',
      emailVerified: true,
    },
  });
  console.log(`✅  Client:  ${client.email}`);

  // ── Artisans ──────────────────────────────────────────────────────────
  const artisanUsers = [];
  for (const a of ARTISANS) {
    const user = await prisma.user.upsert({
      where: { email: a.email },
      update: {},
      create: {
        email: a.email,
        passwordHash,
        fullName: a.name,
        role: 'ARTISAN',
        emailVerified: true,
        artisanProfile: {
          create: {
            trade: a.trade,
            city: a.city,
            bio: `Experienced ${a.trade[0].toLowerCase()} with ${a.years} years in ${a.city}.`,
            yearsExperience: a.years,
            startingRate: a.rate,
            languages: ['English'],
            serviceArea: `All of ${a.city}`,
            verificationStatus: a.verified,
            plan: a.plan,
            rating: a.rating,
            jobsCompleted: a.jobs,
          },
        },
      },
      include: { artisanProfile: true },
    });
    artisanUsers.push(user);
    console.log(`✅  Artisan: ${a.email} (${a.verified})`);
  }

  // ── Jobs ──────────────────────────────────────────────────────────────
  console.log('\n📋  Creating jobs…');

  const chidi   = artisanUsers[0];
  const aisha   = artisanUsers[1];
  const folake  = artisanUsers[3];
  const blessing = artisanUsers[6];

  // Job 1 — CONFIRMED, has review
  const job1 = await prisma.job.upsert({
    where: { id: 'seed-job-0001-0001-0001-000000000001' },
    update: {},
    create: {
      id: 'seed-job-0001-0001-0001-000000000001',
      clientId: client.id,
      artisanUserId: chidi.id,
      title: 'Fix leaking bathroom pipe',
      description: 'Burst pipe under bathroom sink in 3-bedroom flat, Lekki.',
      status: 'CONFIRMED',
      agreedPrice: '₦12,000',
      scheduledAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      startedAt:   new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      completedAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000),
      confirmedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    },
  });

  // Review for job 1
  if (chidi.artisanProfile) {
    await prisma.review.upsert({
      where: { jobId: job1.id },
      update: {},
      create: {
        jobId: job1.id,
        artisanProfileId: chidi.artisanProfile.id,
        reviewerId: client.id,
        reviewerName: client.fullName,
        rating: 5,
        comment: 'Fixed the leak quickly and explained exactly what went wrong. Very professional.',
      },
    });
  }

  // Job 2 — CONFIRMED, has review (Aisha)
  const job2 = await prisma.job.upsert({
    where: { id: 'seed-job-0002-0002-0002-000000000002' },
    update: {},
    create: {
      id: 'seed-job-0002-0002-0002-000000000002',
      clientId: client.id,
      artisanUserId: aisha.id,
      title: 'Rewire kitchen sockets',
      description: 'Three sockets in the kitchen stopped working after power surge.',
      status: 'CONFIRMED',
      agreedPrice: '₦18,000',
      scheduledAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      startedAt:   new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
      completedAt: new Date(Date.now() - 13 * 24 * 60 * 60 * 1000),
      confirmedAt: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000),
    },
  });

  if (aisha.artisanProfile) {
    await prisma.review.upsert({
      where: { jobId: job2.id },
      update: {},
      create: {
        jobId: job2.id,
        artisanProfileId: aisha.artisanProfile.id,
        reviewerId: client.id,
        reviewerName: client.fullName,
        rating: 5,
        comment: 'Showed up on time, clean work. All three sockets working perfectly.',
      },
    });
  }

  // Job 3 — IN_PROGRESS (Blessing)
  await prisma.job.upsert({
    where: { id: 'seed-job-0003-0003-0003-000000000003' },
    update: {},
    create: {
      id: 'seed-job-0003-0003-0003-000000000003',
      clientId: client.id,
      artisanUserId: blessing.id,
      title: 'Full apartment electrical inspection',
      description: 'New flat, need full wiring check before moving in.',
      status: 'IN_PROGRESS',
      agreedPrice: '₦25,000',
      scheduledAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      startedAt:   new Date(Date.now() - 2 * 60 * 60 * 1000),
    },
  });

  // Job 4 — PENDING (Folake)
  await prisma.job.upsert({
    where: { id: 'seed-job-0004-0004-0004-000000000004' },
    update: {},
    create: {
      id: 'seed-job-0004-0004-0004-000000000004',
      clientId: client.id,
      artisanUserId: folake.id,
      title: 'Agbada for family event',
      description: 'Need two complete agbada sets for a naming ceremony in 3 weeks.',
      status: 'PENDING',
      agreedPrice: '₦45,000',
      scheduledAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
    },
  });

  // Job 5 — CANCELLED (Chidi, second job)
  await prisma.job.upsert({
    where: { id: 'seed-job-0005-0005-0005-000000000005' },
    update: {},
    create: {
      id: 'seed-job-0005-0005-0005-000000000005',
      clientId: client.id,
      artisanUserId: chidi.id,
      title: 'Replace kitchen tap',
      description: 'Tap leaking at base.',
      status: 'CANCELLED',
      cancelledAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      cancelledBy: client.id,
      cancelReason: 'Resolved the issue myself.',
    },
  });

  console.log('✅  5 jobs created');

  // ── Message threads ───────────────────────────────────────────────────
  console.log('\n💬  Creating message threads…');

  const thread = await prisma.thread.upsert({
    where: { clientId_artisanId: { clientId: client.id, artisanId: chidi.id } },
    update: {},
    create: { clientId: client.id, artisanId: chidi.id },
  });

  await prisma.message.createMany({
    skipDuplicates: true,
    data: [
      { threadId: thread.id, senderId: client.id, body: 'Hi Chidi, do you handle burst pipes in Lekki?', createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000) },
      { threadId: thread.id, senderId: chidi.id,  body: 'Yes, that\'s my specialty. When would you like me to come?', createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000 + 30 * 60 * 1000) },
      { threadId: thread.id, senderId: client.id, body: 'Tomorrow morning if possible?', createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000 + 60 * 60 * 1000) },
      { threadId: thread.id, senderId: chidi.id,  body: 'I can be there by 9am. Starting estimate ₦12,000.', createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000 + 70 * 60 * 1000) },
      { threadId: thread.id, senderId: client.id, body: 'Perfect, see you then!', createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000 + 80 * 60 * 1000), readAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000 + 90 * 60 * 1000) },
    ],
  });

  console.log('✅  1 thread with 5 messages');

  // ── Summary ───────────────────────────────────────────────────────────
  console.log('\n─────────────────────────────────────────');
  console.log('🔑  All accounts use password: Password123!');
  console.log('\n  admin@artisaneye.com  → ADMIN');
  console.log('  client@test.com       → CLIENT');
  console.log('  chidi@test.com        → ARTISAN (Verified, Pro)');
  console.log('  aisha@test.com        → ARTISAN (Verified)');
  console.log('  ibrahim@test.com      → ARTISAN (Pending verification)');
  console.log('  grace@test.com        → ARTISAN (Unverified)');
  console.log('─────────────────────────────────────────\n');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
